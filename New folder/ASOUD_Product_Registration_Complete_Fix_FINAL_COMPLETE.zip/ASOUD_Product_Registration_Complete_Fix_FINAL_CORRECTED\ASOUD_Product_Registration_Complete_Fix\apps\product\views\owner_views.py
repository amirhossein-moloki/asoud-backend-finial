# apps/product/views/owner_views.py
from rest_framework import views, status, permissions
from rest_framework.response import Response
from utils.response import ApiResponse
from apps.product.models import Product, ProductDiscount, ProductShipping
from apps.product.serializers.owner_serializers import (
    ProductCreateSerializer,
    ProductUpdateSerializer,
    ProductListSerializer,
    ProductDetailSerializer,
    ProductStatusUpdateSerializer
)
from apps.market.models import Market
from apps.advertise.core import AdvertisementCore


class IsProductOwner(permissions.BasePermission):
    """
    Custom permission to only allow owners of a product to edit it.
    """
    def has_object_permission(self, request, view, obj):
        # Check if the product belongs to the user's market
        return obj.market.owner == request.user


class ProductCreateAPIView(views.APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        serializer = ProductCreateSerializer(
            data=request.data,
            context={'request': request},
        )

        if serializer.is_valid(raise_exception=True):
            product = serializer.save()

            # Create advertisement if required
            if product.is_requirement:
                ad_data = AdvertisementCore.create_advertisement_for_product(product)

            # Handle post-creation status based on action
            action = request.data.get('action')  # 'publish' or 'unpublish'
            
            if action == 'publish':
                product.status = Product.QUEUE
                product.save()
                status_message = 'محصول ایجاد شد و برای تایید انتشار ارسال شد'
                status_display = 'در انتظار تایید'
            elif action == 'unpublish':
                product.status = Product.NOT_PUBLISHED
                product.save()
                status_message = 'محصول ایجاد شد و در حالت عدم انتشار قرار گرفت'
                status_display = 'عدم انتشار'
            else:
                status_message = 'محصول با موفقیت ایجاد شد'
                status_display = 'پیش‌نویس'

            success_response = ApiResponse(
                success=True,
                code=201,
                data={
                    'product_id': product.id,
                    'status': product.status,
                    'status_display': status_display,
                    'message': status_message,
                    'next_steps': {
                        'publish': 'برای انتشار محصول، از API وضعیت استفاده کنید',
                        'edit': 'برای ویرایش محصول، از API ویرایش استفاده کنید',
                        'view': 'برای مشاهده جزئیات، از API جزئیات استفاده کنید'
                    }
                },
                message='Product created successfully.',
            )

            return Response(success_response, status=status.HTTP_201_CREATED)


class ProductListAPIView(views.APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, market_id):
        try:
            market = Market.objects.get(id=market_id, owner=request.user)
        except Market.DoesNotExist:
            return Response(
                ApiResponse(
                    success=False,
                    code=404,
                    error="Market not found or access denied"
                ),
                status=status.HTTP_404_NOT_FOUND
            )

        products = Product.objects.filter(market=market).order_by('-created_at')
        serializer = ProductListSerializer(products, many=True)

        return Response(
            ApiResponse(
                success=True,
                code=200,
                data=serializer.data,
                message='Products retrieved successfully'
            )
        )


class ProductDetailAPIView(views.APIView):
    permission_classes = [permissions.IsAuthenticated, IsProductOwner]

    def get(self, request, pk):
        try:
            product = Product.objects.get(pk=pk)
        except Product.DoesNotExist:
            return Response(
                ApiResponse(
                    success=False,
                    code=404,
                    error="Product not found"
                ),
                status=status.HTTP_404_NOT_FOUND
            )

        # Check permission
        self.check_object_permissions(request, product)

        serializer = ProductDetailSerializer(product)
        return Response(
            ApiResponse(
                success=True,
                code=200,
                data=serializer.data,
                message='Product details retrieved successfully'
            )
        )


class ProductUpdateAPIView(views.APIView):
    permission_classes = [permissions.IsAuthenticated, IsProductOwner]

    def put(self, request, pk):
        try:
            product = Product.objects.get(pk=pk)
        except Product.DoesNotExist:
            return Response(
                ApiResponse(
                    success=False,
                    code=404,
                    error="Product not found"
                ),
                status=status.HTTP_404_NOT_FOUND
            )

        # Check permission
        self.check_object_permissions(request, product)

        serializer = ProductUpdateSerializer(
            product,
            data=request.data,
            context={'request': request},
        )

        if serializer.is_valid(raise_exception=True):
            product = serializer.save()

            return Response(
                ApiResponse(
                    success=True,
                    code=200,
                    data={
                        'product_id': product.id,
                        'status': product.status,
                        'message': 'Product updated successfully'
                    },
                    message='Product updated successfully.'
                )
            )


class ProductDeleteAPIView(views.APIView):
    permission_classes = [permissions.IsAuthenticated, IsProductOwner]

    def delete(self, request, pk):
        try:
            product = Product.objects.get(pk=pk)
        except Product.DoesNotExist:
            return Response(
                ApiResponse(
                    success=False,
                    code=404,
                    error="Product not found"
                ),
                status=status.HTTP_404_NOT_FOUND
            )

        # Check permission
        self.check_object_permissions(request, product)

        product.delete()

        return Response(
            ApiResponse(
                success=True,
                code=200,
                data={},
                message='Product deleted successfully'
            )
        )


class ProductStatusUpdateAPIView(views.APIView):
    permission_classes = [permissions.IsAuthenticated, IsProductOwner]

    def patch(self, request, pk):
        try:
            product = Product.objects.get(pk=pk)
        except Product.DoesNotExist:
            return Response(
                ApiResponse(
                    success=False,
                    code=404,
                    error="Product not found"
                ),
                status=status.HTTP_404_NOT_FOUND
            )

        # Check permission
        self.check_object_permissions(request, product)

        serializer = ProductStatusUpdateSerializer(
            product,
            data=request.data,
            partial=True
        )

        if serializer.is_valid(raise_exception=True):
            product = serializer.save()

            # Handle status-specific logic
            if product.status == Product.QUEUE:
                # Send notification to admin for approval
                pass
            elif product.status == Product.PUBLISHED:
                # Product is now live
                pass

            return Response(
                ApiResponse(
                    success=True,
                    code=200,
                    data={
                        'product_id': product.id,
                        'status': product.status,
                        'status_display': product.get_status_display(),
                        'message': f'Product status changed to {product.get_status_display()}'
                    },
                    message='Product status updated successfully.'
                )
            )


class ProductPublishAPIView(views.APIView):
    """
    API for handling product publication workflow
    """
    permission_classes = [permissions.IsAuthenticated, IsProductOwner]

    def post(self, request, pk):
        try:
            product = Product.objects.get(pk=pk)
        except Product.DoesNotExist:
            return Response(
                ApiResponse(
                    success=False,
                    code=404,
                    error="Product not found"
                ),
                status=status.HTTP_404_NOT_FOUND
            )

        # Check permission
        self.check_object_permissions(request, product)

        action = request.data.get('action')  # 'publish' or 'unpublish'

        if action == 'publish':
            if product.status == Product.DRAFT:
                product.status = Product.QUEUE
                product.save()
                
                return Response(
                    ApiResponse(
                        success=True,
                        code=200,
                        data={
                            'product_id': product.id,
                            'status': product.status,
                            'status_display': 'در انتظار تایید',
                            'message': 'درخواست انتشار محصول برای مدیریت ارسال شد'
                        },
                        message='Product submitted for approval.'
                    )
                )
            else:
                return Response(
                    ApiResponse(
                        success=False,
                        code=400,
                        error="Product is not in draft status"
                    ),
                    status=status.HTTP_400_BAD_REQUEST
                )

        elif action == 'unpublish':
            if product.status in [Product.PUBLISHED, Product.QUEUE]:
                product.status = Product.NOT_PUBLISHED
                product.save()
                
                return Response(
                    ApiResponse(
                        success=True,
                        code=200,
                        data={
                            'product_id': product.id,
                            'status': product.status,
                            'status_display': 'عدم انتشار',
                            'message': 'محصول از انتشار خارج شد'
                        },
                        message='Product unpublished successfully.'
                    )
                )
            else:
                return Response(
                    ApiResponse(
                        success=False,
                        code=400,
                        error="Product is not published or in queue"
                    ),
                    status=status.HTTP_400_BAD_REQUEST
                )

        else:
            return Response(
                ApiResponse(
                    success=False,
                    code=400,
                    error="Invalid action. Use 'publish' or 'unpublish'"
                ),
                status=status.HTTP_400_BAD_REQUEST
            )


class ProductDiscountCreateAPIView(views.APIView):
    permission_classes = [permissions.IsAuthenticated, IsProductOwner]

    def post(self, request, pk):
        try:
            product = Product.objects.get(pk=pk)
        except Product.DoesNotExist:
            return Response(
                ApiResponse(
                    success=False,
                    code=404,
                    error="Product not found"
                ),
                status=status.HTTP_404_NOT_FOUND
            )

        # Check permission
        self.check_object_permissions(request, product)

        # Delete existing discounts
        product.discounts.all().delete()

        # Create new discount
        discount_data = request.data.copy()
        discount_data['product'] = product.id
        
        from apps.product.serializers.owner_serializers import ProductDiscountSerializer
        serializer = ProductDiscountSerializer(data=discount_data)
        
        if serializer.is_valid(raise_exception=True):
            discount = serializer.save()
            
            return Response(
                ApiResponse(
                    success=True,
                    code=201,
                    data=serializer.data,
                    message='Product discount created successfully.'
                ),
                status=status.HTTP_201_CREATED
            )


class ProductShippingCreateAPIView(views.APIView):
    permission_classes = [permissions.IsAuthenticated, IsProductOwner]

    def post(self, request, pk):
        try:
            product = Product.objects.get(pk=pk)
        except Product.DoesNotExist:
            return Response(
                ApiResponse(
                    success=False,
                    code=404,
                    error="Product not found"
                ),
                status=status.HTTP_404_NOT_FOUND
            )

        # Check permission
        self.check_object_permissions(request, product)

        # Delete existing shipping options
        product.shipping_options.all().delete()

        # Create new shipping options
        shipping_data = request.data.get('shipping_options', [])
        
        from apps.product.serializers.owner_serializers import ProductShippingSerializer
        created_shipping = []
        
        for shipping in shipping_data:
            shipping['product'] = product.id
            serializer = ProductShippingSerializer(data=shipping)
            if serializer.is_valid(raise_exception=True):
                shipping_obj = serializer.save()
                created_shipping.append(serializer.data)

        return Response(
            ApiResponse(
                success=True,
                code=201,
                data=created_shipping,
                message='Product shipping options created successfully.'
            ),
            status=status.HTTP_201_CREATED
        )


class ProductDiscountListAPIView(views.APIView):
    permission_classes = [permissions.IsAuthenticated, IsProductOwner]

    def get(self, request, pk):
        try:
            product = Product.objects.get(pk=pk)
        except Product.DoesNotExist:
            return Response(
                ApiResponse(
                    success=False,
                    code=404,
                    error="Product not found"
                ),
                status=status.HTTP_404_NOT_FOUND
            )

        # Check permission
        self.check_object_permissions(request, product)

        discounts = product.discounts.all()
        from apps.product.serializers.owner_serializers import ProductDiscountSerializer
        serializer = ProductDiscountSerializer(discounts, many=True)

        return Response(
            ApiResponse(
                success=True,
                code=200,
                data=serializer.data,
                message='Product discounts retrieved successfully.'
            )
        )


class ProductDiscountUpdateAPIView(views.APIView):
    permission_classes = [permissions.IsAuthenticated, IsProductOwner]

    def put(self, request, pk, discount_id):
        try:
            product = Product.objects.get(pk=pk)
        except Product.DoesNotExist:
            return Response(
                ApiResponse(
                    success=False,
                    code=404,
                    error="Product not found"
                ),
                status=status.HTTP_404_NOT_FOUND
            )

        # Check permission
        self.check_object_permissions(request, product)

        try:
            discount = product.discounts.get(id=discount_id)
        except ProductDiscount.DoesNotExist:
            return Response(
                ApiResponse(
                    success=False,
                    code=404,
                    error="Discount not found"
                ),
                status=status.HTTP_404_NOT_FOUND
            )

        from apps.product.serializers.owner_serializers import ProductDiscountSerializer
        serializer = ProductDiscountSerializer(discount, data=request.data)
        
        if serializer.is_valid(raise_exception=True):
            discount = serializer.save()
            
            return Response(
                ApiResponse(
                    success=True,
                    code=200,
                    data=serializer.data,
                    message='Product discount updated successfully.'
                )
            )


class ProductDiscountDeleteAPIView(views.APIView):
    permission_classes = [permissions.IsAuthenticated, IsProductOwner]

    def delete(self, request, pk, discount_id):
        try:
            product = Product.objects.get(pk=pk)
        except Product.DoesNotExist:
            return Response(
                ApiResponse(
                    success=False,
                    code=404,
                    error="Product not found"
                ),
                status=status.HTTP_404_NOT_FOUND
            )

        # Check permission
        self.check_object_permissions(request, product)

        try:
            discount = product.discounts.get(id=discount_id)
        except ProductDiscount.DoesNotExist:
            return Response(
                ApiResponse(
                    success=False,
                    code=404,
                    error="Discount not found"
                ),
                status=status.HTTP_404_NOT_FOUND
            )

        discount.delete()

        return Response(
            ApiResponse(
                success=True,
                code=200,
                data={},
                message='Product discount deleted successfully.'
            )
        )


class ProductShippingListAPIView(views.APIView):
    permission_classes = [permissions.IsAuthenticated, IsProductOwner]

    def get(self, request, pk):
        try:
            product = Product.objects.get(pk=pk)
        except Product.DoesNotExist:
            return Response(
                ApiResponse(
                    success=False,
                    code=404,
                    error="Product not found"
                ),
                status=status.HTTP_404_NOT_FOUND
            )

        # Check permission
        self.check_object_permissions(request, product)

        shipping_options = product.shipping_options.all()
        from apps.product.serializers.owner_serializers import ProductShippingSerializer
        serializer = ProductShippingSerializer(shipping_options, many=True)

        return Response(
            ApiResponse(
                success=True,
                code=200,
                data=serializer.data,
                message='Product shipping options retrieved successfully.'
            )
        )


class ProductShippingUpdateAPIView(views.APIView):
    permission_classes = [permissions.IsAuthenticated, IsProductOwner]

    def put(self, request, pk, shipping_id):
        try:
            product = Product.objects.get(pk=pk)
        except Product.DoesNotExist:
            return Response(
                ApiResponse(
                    success=False,
                    code=404,
                    error="Product not found"
                ),
                status=status.HTTP_404_NOT_FOUND
            )

        # Check permission
        self.check_object_permissions(request, product)

        try:
            shipping = product.shipping_options.get(id=shipping_id)
        except ProductShipping.DoesNotExist:
            return Response(
                ApiResponse(
                    success=False,
                    code=404,
                    error="Shipping option not found"
                ),
                status=status.HTTP_404_NOT_FOUND
            )

        from apps.product.serializers.owner_serializers import ProductShippingSerializer
        serializer = ProductShippingSerializer(shipping, data=request.data)
        
        if serializer.is_valid(raise_exception=True):
            shipping = serializer.save()
            
            return Response(
                ApiResponse(
                    success=True,
                    code=200,
                    data=serializer.data,
                    message='Product shipping option updated successfully.'
                )
            )


class ProductShippingDeleteAPIView(views.APIView):
    permission_classes = [permissions.IsAuthenticated, IsProductOwner]

    def delete(self, request, pk, shipping_id):
        try:
            product = Product.objects.get(pk=pk)
        except Product.DoesNotExist:
            return Response(
                ApiResponse(
                    success=False,
                    code=404,
                    error="Product not found"
                ),
                status=status.HTTP_404_NOT_FOUND
            )

        # Check permission
        self.check_object_permissions(request, product)

        try:
            shipping = product.shipping_options.get(id=shipping_id)
        except ProductShipping.DoesNotExist:
            return Response(
                ApiResponse(
                    success=False,
                    code=404,
                    error="Shipping option not found"
                ),
                status=status.HTTP_404_NOT_FOUND
            )

        shipping.delete()

        return Response(
            ApiResponse(
                success=True,
                code=200,
                data={},
                message='Product shipping option deleted successfully.'
            )
        )
