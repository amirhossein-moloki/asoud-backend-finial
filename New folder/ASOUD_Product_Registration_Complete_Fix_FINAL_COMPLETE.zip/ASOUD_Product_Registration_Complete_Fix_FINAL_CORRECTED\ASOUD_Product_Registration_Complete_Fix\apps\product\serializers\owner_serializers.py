# apps/product/serializers/owner_serializers.py
from rest_framework import serializers
from apps.product.models import (
    Product, ProductImage, ProductDiscount, ProductShipping, ProductKeyword
)
from apps.market.models import Market
from apps.category.models import SubCategory


class KeywordField(serializers.SlugRelatedField):
    def get_queryset(self):
        return ProductKeyword.objects.all()

    def to_internal_value(self, data):
        if isinstance(data, str):
            keyword, created = ProductKeyword.objects.get_or_create(name=data)
            return keyword
        return super().to_internal_value(data)


class ProductImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductImage
        fields = [
            'id',
            'image'
        ]


class ProductShippingSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductShipping
        fields = [
            'id',
            'shipping_method',
            'name',
            'price',
            'is_active'
        ]


class ProductDiscountSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductDiscount
        fields = [
            'id',
            'discount_type',
            'percentage',
            'duration_days',
            'group_count',
            'position',
            'is_active'
        ]


class ProductCreateSerializer(serializers.ModelSerializer):
    keywords = KeywordField(
        many=True,
        queryset=ProductKeyword.objects.all(),
        required=False
    )
    
    type = serializers.ChoiceField(
        choices=Product.TYPE_CHOICES,
    )
    
    tag = serializers.ChoiceField(
        choices=Product.TAG_CHOICES,
        default=Product.NONE,
    )
    
    tag_position = serializers.ChoiceField(
        choices=Product.TAG_POSITION_CHOICES,
        default=Product.TOP_LEFT,
    )
    
    sell_type = serializers.ChoiceField(
        choices=Product.SELL_TYPE_CHOICES,
        default=Product.ONLINE,
    )
    
    ship_cost_pay_type = serializers.ChoiceField(
        choices=Product.SHIP_COST_PAY_TYPE_CHOICES,
        required=False,
        allow_null=True,
    )
    
    # Images
    uploaded_images = serializers.ListField(
        child=serializers.ImageField(allow_empty_file=False), 
        required=False,
        write_only=True
    )
    
    # Discount
    discount = ProductDiscountSerializer(
        required=False,
        write_only=True
    )
    
    # Shipping options
    shipping_options = ProductShippingSerializer(
        many=True,
        required=False,
        write_only=True
    )

    class Meta:
        model = Product
        fields = [
            'market',
            'type',
            'name',
            'description',
            'technical_detail',
            'sub_category',
            'keywords',
            'stock',
            'main_price',
            'colleague_price',
            'marketer_price',
            'maximum_sell_price',
            'required_product',
            'gift_product',
            'is_marketer',
            'is_requirement',
            'status',
            'tag',
            'tag_position',
            'sell_type',
            'ship_cost_pay_type',
            'uploaded_images',
            'discount',
            'shipping_options',
        ]

    def validate(self, data):
        # Validate marketer logic
        if data.get('is_marketer') and not data.get('marketer_price'):
            raise serializers.ValidationError({
                'marketer_price': 'Marketer price is required when is_marketer is True'
            })
        
        # Validate service logic
        if data.get('type') == Product.SERVICE:
            # For services, shipping is not required
            if data.get('ship_cost_pay_type'):
                raise serializers.ValidationError({
                    'ship_cost_pay_type': 'Shipping cost payment type is not applicable for services'
                })
        
        # Validate good logic
        if data.get('type') == Product.GOOD:
            # For goods, shipping is required
            if not data.get('ship_cost_pay_type'):
                raise serializers.ValidationError({
                    'ship_cost_pay_type': 'Shipping cost payment type is required for goods'
                })
        
        return data

    def create(self, validated_data):
        # Extract nested data
        images = validated_data.pop('uploaded_images', [])
        discount_data = validated_data.pop('discount', None)
        shipping_options_data = validated_data.pop('shipping_options', [])
        
        # Create product
        product = Product.objects.create(**validated_data)
        
        # Create images
        for image in images:
            ProductImage.objects.create(product=product, image=image)
        
        # Create discount if provided
        if discount_data:
            ProductDiscount.objects.create(product=product, **discount_data)
        
        # Create shipping options (only for goods)
        if product.type == Product.GOOD:
            for shipping_data in shipping_options_data:
                ProductShipping.objects.create(product=product, **shipping_data)
        
        return product

    def update(self, instance, validated_data):
        # Extract nested data
        images = validated_data.pop('uploaded_images', [])
        discount_data = validated_data.pop('discount', None)
        shipping_options_data = validated_data.pop('shipping_options', [])
        
        # Update product
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()
        
        # Update images
        if images:
            # Delete existing images
            instance.images.all().delete()
            # Create new images
            for image in images:
                ProductImage.objects.create(product=instance, image=image)
        
        # Update discount
        if discount_data:
            # Delete existing discount
            instance.discounts.all().delete()
            # Create new discount
            ProductDiscount.objects.create(product=instance, **discount_data)
        
        # Update shipping options
        if shipping_options_data:
            # Delete existing shipping options
            instance.shipping_options.all().delete()
            # Create new shipping options
            for shipping_data in shipping_options_data:
                ProductShipping.objects.create(product=instance, **shipping_data)
        
        return instance


class ProductUpdateSerializer(ProductCreateSerializer):
    class Meta(ProductCreateSerializer.Meta):
        fields = ProductCreateSerializer.Meta.fields


class ProductListSerializer(serializers.ModelSerializer):
    images = ProductImageSerializer(many=True, read_only=True)
    discount = ProductDiscountSerializer(many=True, read_only=True)
    shipping_options = ProductShippingSerializer(many=True, read_only=True)
    keywords = KeywordField(many=True, read_only=True)
    
    class Meta:
        model = Product
        fields = [
            'id',
            'name',
            'description',
            'main_price',
            'stock',
            'status',
            'tag',
            'tag_position',
            'images',
            'discount',
            'shipping_options',
            'keywords',
            'created_at',
            'updated_at',
        ]


class ProductDetailSerializer(serializers.ModelSerializer):
    required_product = ProductListSerializer(read_only=True)
    gift_product = ProductListSerializer(read_only=True)
    keywords = KeywordField(many=True, read_only=True)
    images = ProductImageSerializer(many=True, read_only=True)
    discount = ProductDiscountSerializer(many=True, read_only=True)
    shipping_options = ProductShippingSerializer(many=True, read_only=True)
    
    class Meta:
        model = Product
        fields = [
            'id',
            'market',
            'type',
            'name',
            'description',
            'technical_detail',
            'sub_category',
            'keywords',
            'stock',
            'main_price',
            'colleague_price',
            'marketer_price',
            'maximum_sell_price',
            'required_product',
            'gift_product',
            'is_marketer',
            'is_requirement',
            'tag',
            'tag_position',
            'sell_type',
            'ship_cost_pay_type',
            'images',
            'discount',
            'shipping_options',
            'status',
            'created_at',
            'updated_at',
        ]


class ProductStatusUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = ['status']

    def validate_status(self, value):
        valid_transitions = {
            Product.DRAFT: [Product.QUEUE, Product.NOT_PUBLISHED, Product.INACTIVE],
            Product.QUEUE: [Product.PUBLISHED, Product.NEEDS_EDITING, Product.INACTIVE],
            Product.NOT_PUBLISHED: [Product.QUEUE, Product.INACTIVE],
            Product.PUBLISHED: [Product.NOT_PUBLISHED, Product.INACTIVE],
            Product.NEEDS_EDITING: [Product.QUEUE, Product.INACTIVE],
            Product.INACTIVE: [Product.DRAFT, Product.QUEUE],
        }
        
        current_status = self.instance.status if self.instance else Product.DRAFT
        if value not in valid_transitions.get(current_status, []):
            raise serializers.ValidationError(
                f"Cannot change status from {current_status} to {value}"
            )
        
        return value
