# apps/product/urls/owner_urls.py
from django.urls import path

from apps.product.views.owner_views import (
    ProductCreateAPIView,
    ProductListAPIView,
    ProductDetailAPIView,
    ProductUpdateAPIView,
    ProductDeleteAPIView,
    ProductStatusUpdateAPIView,
    ProductPublishAPIView,
    ProductDiscountCreateAPIView,
    ProductDiscountListAPIView,
    ProductDiscountUpdateAPIView,
    ProductDiscountDeleteAPIView,
    ProductShippingCreateAPIView,
    ProductShippingListAPIView,
    ProductShippingUpdateAPIView,
    ProductShippingDeleteAPIView,
)

app_name = 'product_owner'

urlpatterns = [
    # Product CRUD
    path(
        'create/',
        ProductCreateAPIView.as_view(),
        name='create',
    ),
    path(
        'list/<str:market_id>/',
        ProductListAPIView.as_view(),
        name='list',
    ),
    path(
        'detail/<str:pk>/',
        ProductDetailAPIView.as_view(),
        name='detail',
    ),
    path(
        'update/<str:pk>/',
        ProductUpdateAPIView.as_view(),
        name='update',
    ),
    path(
        'delete/<str:pk>/',
        ProductDeleteAPIView.as_view(),
        name='delete',
    ),
    
    # Product Status Management
    path(
        'status/<str:pk>/',
        ProductStatusUpdateAPIView.as_view(),
        name='status-update',
    ),
    path(
        'publish/<str:pk>/',
        ProductPublishAPIView.as_view(),
        name='publish',
    ),
    
    # Product Discount Management
    path(
        'discount/create/<str:pk>/',
        ProductDiscountCreateAPIView.as_view(),
        name='discount-create'
    ),
    path(
        'discount/list/<str:pk>/',
        ProductDiscountListAPIView.as_view(),
        name='discount-list'
    ),
    path(
        'discount/update/<str:pk>/<str:discount_id>/',
        ProductDiscountUpdateAPIView.as_view(),
        name='discount-update'
    ),
    path(
        'discount/delete/<str:pk>/<str:discount_id>/',
        ProductDiscountDeleteAPIView.as_view(),
        name='discount-delete'
    ),
    
    # Product Shipping Management
    path(
        'shipping/create/<str:pk>/',
        ProductShippingCreateAPIView.as_view(),
        name='shipping-create'
    ),
    path(
        'shipping/list/<str:pk>/',
        ProductShippingListAPIView.as_view(),
        name='shipping-list'
    ),
    path(
        'shipping/update/<str:pk>/<str:shipping_id>/',
        ProductShippingUpdateAPIView.as_view(),
        name='shipping-update'
    ),
    path(
        'shipping/delete/<str:pk>/<str:shipping_id>/',
        ProductShippingDeleteAPIView.as_view(),
        name='shipping-delete'
    ),
]
