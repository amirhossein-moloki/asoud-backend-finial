# apps/product/admin.py
from django.contrib import admin
from apps.core.admin import BaseAdmin, BaseTabularInline
from apps.product.models import (
    Product, ProductImage, ProductDiscount, ProductShipping, 
    ProductKeyword, ProductTheme
)


class ProductImageTabularInline(BaseTabularInline):
    model = ProductImage
    extra = 0
    fields = (
        'image',
    ) + BaseTabularInline.fields
    readonly_fields = BaseTabularInline.readonly_fields


class ProductDiscountTabularInline(BaseTabularInline):
    model = ProductDiscount
    extra = 0
    fields = (
        'discount_type',
        'percentage',
        'duration_days',
        'group_count',
        'position',
        'is_active',
    ) + BaseTabularInline.fields
    readonly_fields = BaseTabularInline.readonly_fields


class ProductShippingTabularInline(BaseTabularInline):
    model = ProductShipping
    extra = 0
    fields = (
        'shipping_method',
        'name',
        'price',
        'is_active',
    ) + BaseTabularInline.fields
    readonly_fields = BaseTabularInline.readonly_fields


class ProductAdmin(BaseAdmin):
    inlines = [
        ProductImageTabularInline,
        ProductDiscountTabularInline,
        ProductShippingTabularInline,
    ]

    list_display = [
        'name',
        'market',
        'type',
        'main_price',
        'stock',
        'status',
        'created_at',
    ]

    list_filter = [
        'type',
        'status',
        'is_marketer',
        'is_requirement',
        'created_at',
    ]

    search_fields = [
        'name',
        'description',
        'market__name',
    ]

    fields = (
        'market',
        'type',
        'name',
        'description',
        'technical_detail',
        'sub_category',
        'keywords',
        'stock',
        'main_price',
        'colleague_price',
        'marketer_price',
        'maximum_sell_price',
        'status',
        'required_product',
        'gift_product',
        'is_marketer',
        'is_requirement',
        'tag',
        'tag_position',
        'sell_type',
        'ship_cost_pay_type',
        'theme',
        'theme_index',
    ) + BaseAdmin.fields

    readonly_fields = BaseAdmin.readonly_fields


class ProductKeywordAdmin(BaseAdmin):
    list_display = [
        'name',
        'created_at',
    ]

    search_fields = [
        'name',
    ]

    fields = (
        'name',
    ) + BaseAdmin.fields

    readonly_fields = BaseAdmin.readonly_fields


class ProductThemeAdmin(BaseAdmin):
    list_display = [
        'name',
        'created_at',
    ]

    search_fields = [
        'name',
    ]

    fields = (
        'name',
    ) + BaseAdmin.fields

    readonly_fields = BaseAdmin.readonly_fields


class ProductDiscountAdmin(BaseAdmin):
    list_display = [
        'product',
        'discount_type',
        'percentage',
        'duration_days',
        'group_count',
        'position',
        'is_active',
    ]

    list_filter = [
        'discount_type',
        'is_active',
        'position',
    ]

    search_fields = [
        'product__name',
    ]

    fields = (
        'product',
        'discount_type',
        'percentage',
        'duration_days',
        'group_count',
        'position',
        'is_active',
    ) + BaseAdmin.fields

    readonly_fields = BaseAdmin.readonly_fields


class ProductShippingAdmin(BaseAdmin):
    list_display = [
        'product',
        'shipping_method',
        'name',
        'price',
        'is_active',
    ]

    list_filter = [
        'shipping_method',
        'is_active',
    ]

    search_fields = [
        'product__name',
        'name',
    ]

    fields = (
        'product',
        'shipping_method',
        'name',
        'price',
        'is_active',
    ) + BaseAdmin.fields

    readonly_fields = BaseAdmin.readonly_fields


admin.site.register(Product, ProductAdmin)
admin.site.register(ProductKeyword, ProductKeywordAdmin)
admin.site.register(ProductTheme, ProductThemeAdmin)
admin.site.register(ProductDiscount, ProductDiscountAdmin)
admin.site.register(ProductShipping, ProductShippingAdmin)
