from rest_framework import views, status, permissions
from rest_framework.response import Response
from django.shortcuts import get_object_or_404

from apps.market.models import Market
from apps.market.ml.recommendation_engine import MarketRecommendationEngine
from apps.base.utils import ApiResponse


class MarketRecommendationAPIView(views.APIView):
    """
    API برای دریافت پیشنهادات فروشگاه‌ها
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, format=None):
        user = request.user
        
        # دریافت پارامترها
        algorithm = request.GET.get('algorithm', 'hybrid')  # hybrid, collaborative, content, popular, trending
        limit = int(request.GET.get('limit', 10))
        
        # محدود کردن تعداد پیشنهادات
        limit = min(limit, 50)  # حداکثر 50 پیشنهاد
        
        # ایجاد موتور پیشنهادات
        engine = MarketRecommendationEngine()
        
        # دریافت پیشنهادات بر اساس الگوریتم انتخاب شده
        if algorithm == 'collaborative':
            recommendations = engine.get_user_recommendations(user, limit)
        elif algorithm == 'content':
            recommendations = engine.get_content_based_recommendations(user, limit)
        elif algorithm == 'popular':
            recommendations = engine.get_popular_markets(limit)
        elif algorithm == 'trending':
            recommendations = engine.get_trending_markets(limit)
        else:  # hybrid (پیش‌فرض)
            recommendations = engine.get_hybrid_recommendations(user, limit)
        
        # اضافه کردن اطلاعات اضافی
        for rec in recommendations:
            try:
                market = Market.objects.get(id=rec['market_id'])
                rec['market_url'] = f"https://{market.business_id.lower()}.asoud.ir"
                rec['description'] = market.description
                rec['created_at'] = market.created_at
            except Market.DoesNotExist:
                continue
        
        data = {
            'algorithm': algorithm,
            'user_id': user.id,
            'recommendations': recommendations,
            'total_count': len(recommendations),
        }
        
        success_response = ApiResponse(
            success=True,
            code=200,
            data=data,
            message=f'پیشنهادات {algorithm} دریافت شد'
        )
        
        return Response(success_response, status=status.HTTP_200_OK)


class MarketSimilarityAPIView(views.APIView):
    """
    API برای یافتن فروشگاه‌های مشابه
    """
    permission_classes = [permissions.AllowAny]

    def get(self, request, market_id, format=None):
        try:
            market = Market.objects.get(id=market_id, status=Market.PUBLISHED)
        except Market.DoesNotExist:
            return Response(
                ApiResponse(
                    success=False,
                    code=404,
                    error="فروشگاه یافت نشد"
                ),
                status=status.HTTP_404_NOT_FOUND
            )
        
        limit = int(request.GET.get('limit', 5))
        limit = min(limit, 20)  # حداکثر 20 فروشگاه مشابه
        
        # ایجاد موتور پیشنهادات
        engine = MarketRecommendationEngine()
        
        # یافتن فروشگاه‌های مشابه بر اساس دسته‌بندی
        similar_markets = Market.objects.filter(
            sub_category=market.sub_category,
            status=Market.PUBLISHED
        ).exclude(id=market.id).annotate(
            total_likes=Count('liked_by', filter=Q(liked_by__is_active=True)),
            total_views=Count('viewed_by'),
        ).order_by('-total_likes', '-total_views')[:limit]
        
        recommendations = []
        for similar_market in similar_markets:
            # محاسبه امتیاز شباهت
            similarity_score = 1.0  # شباهت کامل در دسته‌بندی
            
            recommendations.append({
                'market_id': similar_market.id,
                'market_name': similar_market.name,
                'business_id': similar_market.business_id,
                'similarity_score': similarity_score,
                'reason': f'همان دسته‌بندی: {market.sub_category.title}',
                'sub_category': similar_market.sub_category.title if similar_market.sub_category else None,
                'logo_url': similar_market.logo_img.url if similar_market.logo_img else None,
                'market_url': f"https://{similar_market.business_id.lower()}.asoud.ir",
                'stats': {
                    'likes': similar_market.total_likes,
                    'views': similar_market.total_views,
                }
            })
        
        data = {
            'original_market': {
                'id': market.id,
                'name': market.name,
                'business_id': market.business_id,
                'sub_category': market.sub_category.title if market.sub_category else None,
            },
            'similar_markets': recommendations,
            'total_count': len(recommendations),
        }
        
        success_response = ApiResponse(
            success=True,
            code=200,
            data=data,
            message='فروشگاه‌های مشابه دریافت شد'
        )
        
        return Response(success_response, status=status.HTTP_200_OK)


class MarketTrendingAPIView(views.APIView):
    """
    API برای دریافت فروشگاه‌های ترند
    """
    permission_classes = [permissions.AllowAny]

    def get(self, request, format=None):
        limit = int(request.GET.get('limit', 10))
        limit = min(limit, 50)  # حداکثر 50 فروشگاه
        
        # ایجاد موتور پیشنهادات
        engine = MarketRecommendationEngine()
        
        # دریافت فروشگاه‌های ترند
        trending_markets = engine.get_trending_markets(limit)
        
        data = {
            'trending_markets': trending_markets,
            'total_count': len(trending_markets),
            'period': '7 روز گذشته',
        }
        
        success_response = ApiResponse(
            success=True,
            code=200,
            data=data,
            message='فروشگاه‌های ترند دریافت شد'
        )
        
        return Response(success_response, status=status.HTTP_200_OK)


class MarketPopularAPIView(views.APIView):
    """
    API برای دریافت فروشگاه‌های محبوب
    """
    permission_classes = [permissions.AllowAny]

    def get(self, request, format=None):
        limit = int(request.GET.get('limit', 10))
        limit = min(limit, 50)  # حداکثر 50 فروشگاه
        
        # ایجاد موتور پیشنهادات
        engine = MarketRecommendationEngine()
        
        # دریافت فروشگاه‌های محبوب
        popular_markets = engine.get_popular_markets(limit)
        
        data = {
            'popular_markets': popular_markets,
            'total_count': len(popular_markets),
        }
        
        success_response = ApiResponse(
            success=True,
            code=200,
            data=data,
            message='فروشگاه‌های محبوب دریافت شد'
        )
        
        return Response(success_response, status=status.HTTP_200_OK)


class MarketRecommendationStatsAPIView(views.APIView):
    """
    API برای آمار سیستم پیشنهادات
    """
    permission_classes = [permissions.IsAdminUser]

    def get(self, request, format=None):
        from apps.market.models import MarketLike, MarketView
        from django.db.models import Count
        
        # آمار کلی سیستم پیشنهادات
        total_markets = Market.objects.filter(status=Market.PUBLISHED).count()
        total_likes = MarketLike.objects.filter(is_active=True).count()
        total_views = MarketView.objects.count()
        
        # آمار کاربران فعال
        active_users = MarketLike.objects.values('user').distinct().count()
        
        # آمار دسته‌بندی‌ها
        category_stats = Market.objects.filter(
            status=Market.PUBLISHED
        ).values('sub_category__title').annotate(
            market_count=Count('id'),
            total_likes=Count('liked_by', filter=Q(liked_by__is_active=True)),
        ).order_by('-market_count')[:10]
        
        # آمار الگوریتم‌ها (شبیه‌سازی)
        algorithm_stats = {
            'collaborative_filtering': {
                'usage_count': 150,
                'accuracy': 0.75,
                'description': 'فیلتر همکاری'
            },
            'content_based': {
                'usage_count': 120,
                'accuracy': 0.68,
                'description': 'بر اساس محتوا'
            },
            'hybrid': {
                'usage_count': 200,
                'accuracy': 0.82,
                'description': 'ترکیبی'
            },
            'popular': {
                'usage_count': 300,
                'accuracy': 0.60,
                'description': 'محبوب'
            },
            'trending': {
                'usage_count': 180,
                'accuracy': 0.70,
                'description': 'ترند'
            }
        }
        
        data = {
            'overall_stats': {
                'total_markets': total_markets,
                'total_likes': total_likes,
                'total_views': total_views,
                'active_users': active_users,
            },
            'category_stats': list(category_stats),
            'algorithm_stats': algorithm_stats,
        }
        
        success_response = ApiResponse(
            success=True,
            code=200,
            data=data,
            message='آمار سیستم پیشنهادات دریافت شد'
        )
        
        return Response(success_response, status=status.HTTP_200_OK)



