from rest_framework import views, status, permissions
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from django.db.models import Count, Q
from django.core.cache import cache
from django.utils import timezone
from datetime import timedelta
import json

from apps.market.models import Market, MarketLike, MarketView, MarketBookmark
from apps.comment.models import Comment
from apps.base.utils import ApiResponse


class MobileMarketListAPIView(views.APIView):
    """
    لیست فروشگاه‌ها بهینه شده برای موبایل
    """
    permission_classes = [permissions.AllowAny]

    def get(self, request, format=None):
        # پارامترهای فیلتر
        page = int(request.GET.get('page', 1))
        page_size = min(int(request.GET.get('page_size', 20)), 50)  # حداکثر 50 آیتم
        category_id = request.GET.get('category_id')
        search = request.GET.get('search', '').strip()
        
        # کش کلید
        cache_key = f"mobile_markets_{page}_{page_size}_{category_id}_{search}"
        cached_data = cache.get(cache_key)
        
        if cached_data:
            return Response(cached_data)
        
        # کوئری بهینه شده
        queryset = Market.objects.filter(
            status=Market.PUBLISHED
        ).select_related('sub_category', 'user').prefetch_related(
            'liked_by', 'viewed_by'
        ).only(
            'id', 'name', 'business_id', 'logo_img', 'background_img',
            'sub_category__title', 'user__first_name', 'user__last_name'
        )
        
        # اعمال فیلترها
        if category_id:
            queryset = queryset.filter(sub_category_id=category_id)
        
        if search:
            queryset = queryset.filter(
                Q(name__icontains=search) | 
                Q(business_id__icontains=search)
            )
        
        # صفحه‌بندی
        start = (page - 1) * page_size
        end = start + page_size
        markets = queryset[start:end]
        
        # ساخت داده‌های بهینه شده
        data = []
        for market in markets:
            # محاسبه آمار سریع
            like_count = market.liked_by.filter(is_active=True).count()
            view_count = market.viewed_by.count()
            
            data.append({
                'id': market.id,
                'name': market.name,
                'business_id': market.business_id,
                'logo_url': market.logo_img.url if market.logo_img else None,
                'background_url': market.background_img.url if market.background_img else None,
                'sub_category': market.sub_category.title if market.sub_category else None,
                'owner_name': f"{market.user.first_name} {market.user.last_name}".strip(),
                'stats': {
                    'likes': like_count,
                    'views': view_count,
                },
                'share_url': f"https://{market.business_id.lower()}.asoud.ir",
            })
        
        response_data = {
            'markets': data,
            'pagination': {
                'page': page,
                'page_size': page_size,
                'has_more': len(data) == page_size,
            }
        }
        
        # کش کردن نتیجه (5 دقیقه)
        cache.set(cache_key, response_data, 300)
        
        success_response = ApiResponse(
            success=True,
            code=200,
            data=response_data,
            message='لیست فروشگاه‌ها دریافت شد'
        )
        
        return Response(success_response, status=status.HTTP_200_OK)


class MobileMarketDetailAPIView(views.APIView):
    """
    جزئیات فروشگاه بهینه شده برای موبایل
    """
    permission_classes = [permissions.AllowAny]

    def get(self, request, market_id, format=None):
        try:
            market = Market.objects.select_related(
                'sub_category', 'user', 'location', 'contact'
            ).get(id=market_id, status=Market.PUBLISHED)
        except Market.DoesNotExist:
            return Response(
                ApiResponse(
                    success=False,
                    code=404,
                    error="فروشگاه یافت نشد"
                ),
                status=status.HTTP_404_NOT_FOUND
            )
        
        # کش کلید
        cache_key = f"mobile_market_detail_{market_id}"
        cached_data = cache.get(cache_key)
        
        if cached_data:
            return Response(cached_data)
        
        # محاسبه آمار
        like_count = market.liked_by.filter(is_active=True).count()
        view_count = market.viewed_by.count()
        comment_count = Comment.objects.filter(
            content_type__model='market',
            object_id=market.id
        ).count()
        bookmark_count = market.bookmarked_by.filter(is_active=True).count()
        
        # بررسی وضعیت کاربر (اگر وارد شده باشد)
        user_liked = False
        user_bookmarked = False
        
        if request.user.is_authenticated:
            user_liked = market.liked_by.filter(
                user=request.user, is_active=True
            ).exists()
            user_bookmarked = market.bookmarked_by.filter(
                user=request.user, is_active=True
            ).exists()
        
        # ساخت داده‌های بهینه شده
        data = {
            'id': market.id,
            'name': market.name,
            'business_id': market.business_id,
            'description': market.description,
            'logo_url': market.logo_img.url if market.logo_img else None,
            'background_url': market.background_img.url if market.background_img else None,
            'sub_category': market.sub_category.title if market.sub_category else None,
            'owner': {
                'id': market.user.id,
                'name': f"{market.user.first_name} {market.user.last_name}".strip(),
            },
            'location': {
                'city': market.location.city.name if market.location and market.location.city else None,
                'address': market.location.address if market.location else None,
            } if market.location else None,
            'contact': {
                'mobile': market.contact.first_mobile_number if market.contact else None,
                'email': market.contact.email if market.contact else None,
                'website': market.contact.website_url if market.contact else None,
            } if market.contact else None,
            'stats': {
                'likes': like_count,
                'views': view_count,
                'comments': comment_count,
                'bookmarks': bookmark_count,
            },
            'user_interactions': {
                'is_liked': user_liked,
                'is_bookmarked': user_bookmarked,
            },
            'share_url': f"https://{market.business_id.lower()}.asoud.ir",
            'created_at': market.created_at,
        }
        
        # کش کردن نتیجه (10 دقیقه)
        cache.set(cache_key, data, 600)
        
        success_response = ApiResponse(
            success=True,
            code=200,
            data=data,
            message='جزئیات فروشگاه دریافت شد'
        )
        
        return Response(success_response, status=status.HTTP_200_OK)


class MobileMarketIconsAPIView(views.APIView):
    """
    آیکون‌های فروشگاه بهینه شده برای موبایل
    """
    permission_classes = [permissions.AllowAny]

    def get(self, request, market_id, format=None):
        try:
            market = Market.objects.get(id=market_id, status=Market.PUBLISHED)
        except Market.DoesNotExist:
            return Response(
                ApiResponse(
                    success=False,
                    code=404,
                    error="فروشگاه یافت نشد"
                ),
                status=status.HTTP_404_NOT_FOUND
            )
        
        # محاسبه آمار سریع
        like_count = market.liked_by.filter(is_active=True).count()
        view_count = market.viewed_by.count()
        comment_count = Comment.objects.filter(
            content_type__model='market',
            object_id=market.id
        ).count()
        bookmark_count = market.bookmarked_by.filter(is_active=True).count()
        
        # بررسی وضعیت کاربر
        user_liked = False
        user_bookmarked = False
        
        if request.user.is_authenticated:
            user_liked = market.liked_by.filter(
                user=request.user, is_active=True
            ).exists()
            user_bookmarked = market.bookmarked_by.filter(
                user=request.user, is_active=True
            ).exists()
        
        # ساخت داده‌های آیکون‌ها
        data = {
            'market_id': market.id,
            'market_name': market.name,
            'icons': {
                'like': {
                    'count': like_count,
                    'is_liked': user_liked,
                    'url': f'/api/market/icons/like/{market_id}/',
                },
                'view': {
                    'count': view_count,
                    'url': f'/api/market/icons/view/{market_id}/stats/',
                },
                'comment': {
                    'count': comment_count,
                    'url': f'/api/comment/comments/market/{market_id}/',
                },
                'bookmark': {
                    'count': bookmark_count,
                    'is_bookmarked': user_bookmarked,
                    'url': f'/api/market/bookmark/{market_id}/',
                },
                'share': {
                    'url': f'/api/market/icons/share/{market_id}/',
                    'share_url': f"https://{market.business_id.lower()}.asoud.ir",
                },
                'report': {
                    'url': f'/api/market/report/{market_id}/',
                },
                'audio_guide': {
                    'available': True,
                    'url': f'/api/market/icons/audio-guide/{market_id}/',
                },
            }
        }
        
        success_response = ApiResponse(
            success=True,
            code=200,
            data=data,
            message='آیکون‌های فروشگاه دریافت شد'
        )
        
        return Response(success_response, status=status.HTTP_200_OK)


class MobileMarketSearchAPIView(views.APIView):
    """
    جستجوی فروشگاه‌ها بهینه شده برای موبایل
    """
    permission_classes = [permissions.AllowAny]

    def get(self, request, format=None):
        query = request.GET.get('q', '').strip()
        category_id = request.GET.get('category_id')
        page = int(request.GET.get('page', 1))
        page_size = min(int(request.GET.get('page_size', 20)), 50)
        
        if not query:
            return Response(
                ApiResponse(
                    success=False,
                    code=400,
                    error="پارامتر جستجو الزامی است"
                ),
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # کش کلید
        cache_key = f"mobile_search_{query}_{category_id}_{page}_{page_size}"
        cached_data = cache.get(cache_key)
        
        if cached_data:
            return Response(cached_data)
        
        # جستجو
        queryset = Market.objects.filter(
            status=Market.PUBLISHED,
            Q(name__icontains=query) |
            Q(business_id__icontains=query) |
            Q(description__icontains=query)
        ).select_related('sub_category').only(
            'id', 'name', 'business_id', 'logo_img', 'sub_category__title'
        )
        
        if category_id:
            queryset = queryset.filter(sub_category_id=category_id)
        
        # صفحه‌بندی
        start = (page - 1) * page_size
        end = start + page_size
        markets = queryset[start:end]
        
        # ساخت نتایج
        results = []
        for market in markets:
            results.append({
                'id': market.id,
                'name': market.name,
                'business_id': market.business_id,
                'logo_url': market.logo_img.url if market.logo_img else None,
                'sub_category': market.sub_category.title if market.sub_category else None,
                'share_url': f"https://{market.business_id.lower()}.asoud.ir",
            })
        
        response_data = {
            'query': query,
            'results': results,
            'pagination': {
                'page': page,
                'page_size': page_size,
                'has_more': len(results) == page_size,
            }
        }
        
        # کش کردن نتیجه (2 دقیقه)
        cache.set(cache_key, response_data, 120)
        
        success_response = ApiResponse(
            success=True,
            code=200,
            data=response_data,
            message='نتایج جستجو دریافت شد'
        )
        
        return Response(success_response, status=status.HTTP_200_OK)


class MobileMarketTrendingAPIView(views.APIView):
    """
    فروشگاه‌های ترند بهینه شده برای موبایل
    """
    permission_classes = [permissions.AllowAny]

    def get(self, request, format=None):
        limit = min(int(request.GET.get('limit', 10)), 20)
        
        # کش کلید
        cache_key = f"mobile_trending_{limit}"
        cached_data = cache.get(cache_key)
        
        if cached_data:
            return Response(cached_data)
        
        # فروشگاه‌های ترند (7 روز گذشته)
        week_ago = timezone.now() - timedelta(days=7)
        
        trending_markets = Market.objects.filter(
            status=Market.PUBLISHED,
            liked_by__created_at__gte=week_ago
        ).annotate(
            recent_likes=Count('liked_by', filter=Q(
                liked_by__is_active=True,
                liked_by__created_at__gte=week_ago
            )),
            total_likes=Count('liked_by', filter=Q(liked_by__is_active=True)),
        ).order_by('-recent_likes', '-total_likes')[:limit]
        
        # ساخت نتایج
        results = []
        for market in trending_markets:
            results.append({
                'id': market.id,
                'name': market.name,
                'business_id': market.business_id,
                'logo_url': market.logo_img.url if market.logo_img else None,
                'sub_category': market.sub_category.title if market.sub_category else None,
                'recent_likes': market.recent_likes,
                'total_likes': market.total_likes,
                'share_url': f"https://{market.business_id.lower()}.asoud.ir",
            })
        
        response_data = {
            'trending_markets': results,
            'period': '7 روز گذشته',
            'total_count': len(results),
        }
        
        # کش کردن نتیجه (15 دقیقه)
        cache.set(cache_key, response_data, 900)
        
        success_response = ApiResponse(
            success=True,
            code=200,
            data=response_data,
            message='فروشگاه‌های ترند دریافت شد'
        )
        
        return Response(success_response, status=status.HTTP_200_OK)



