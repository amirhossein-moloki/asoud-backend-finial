from rest_framework import views, status, permissions
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from django.db.models import Count, Avg, Sum, Q, F
from django.utils import timezone
from datetime import timedelta, datetime

from apps.market.models import Market, MarketLike, MarketView, MarketBookmark
from apps.market.models.analytics_models import MarketAnalytics, MarketEngagementLog
from apps.market.models.notification_models import Notification
from apps.comment.models import Comment
from apps.base.utils import ApiResponse


class MarketDashboardAPIView(views.APIView):
    """
    داشبورد مدیریتی فروشگاه
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, market_id, format=None):
        market = get_object_or_404(Market, id=market_id, user=request.user)
        
        # آمار کلی
        total_views = MarketView.objects.filter(market=market).count()
        total_likes = MarketLike.objects.filter(market=market, is_active=True).count()
        total_comments = Comment.objects.filter(
            content_type__model='market',
            object_id=market.id
        ).count()
        total_bookmarks = MarketBookmark.objects.filter(market=market, is_active=True).count()
        
        # آمار امروز
        today = timezone.now().date()
        today_views = MarketView.objects.filter(
            market=market,
            created_at__date=today
        ).count()
        today_likes = MarketLike.objects.filter(
            market=market,
            is_active=True,
            created_at__date=today
        ).count()
        today_comments = Comment.objects.filter(
            content_type__model='market',
            object_id=market.id,
            created_at__date=today
        ).count()
        
        # آمار هفته
        week_ago = timezone.now() - timedelta(days=7)
        week_views = MarketView.objects.filter(
            market=market,
            created_at__gte=week_ago
        ).count()
        week_likes = MarketLike.objects.filter(
            market=market,
            is_active=True,
            created_at__gte=week_ago
        ).count()
        
        # آمار ماه
        month_ago = timezone.now() - timedelta(days=30)
        month_views = MarketView.objects.filter(
            market=market,
            created_at__gte=month_ago
        ).count()
        month_likes = MarketLike.objects.filter(
            market=market,
            is_active=True,
            created_at__gte=month_ago
        ).count()
        
        # آخرین فعالیت‌ها
        recent_activities = []
        
        # آخرین لایک‌ها
        recent_likes = MarketLike.objects.filter(
            market=market,
            is_active=True
        ).select_related('user').order_by('-created_at')[:5]
        
        for like in recent_likes:
            recent_activities.append({
                'type': 'like',
                'user_name': like.user.get_full_name() if like.user else 'کاربر مهمان',
                'timestamp': like.created_at,
                'message': f'{like.user.get_full_name() if like.user else "کاربر مهمان"} فروشگاه را لایک کرد'
            })
        
        # آخرین نظرات
        recent_comments = Comment.objects.filter(
            content_type__model='market',
            object_id=market.id
        ).select_related('creator').order_by('-created_at')[:5]
        
        for comment in recent_comments:
            recent_activities.append({
                'type': 'comment',
                'user_name': comment.creator.get_full_name() if comment.creator else 'کاربر مهمان',
                'timestamp': comment.created_at,
                'message': f'{comment.creator.get_full_name() if comment.creator else "کاربر مهمان"} نظر جدیدی ارسال کرد'
            })
        
        # آخرین بازدیدها
        recent_views = MarketView.objects.filter(
            market=market
        ).select_related('user').order_by('-created_at')[:5]
        
        for view in recent_views:
            recent_activities.append({
                'type': 'view',
                'user_name': view.user.get_full_name() if view.user else 'کاربر مهمان',
                'timestamp': view.created_at,
                'message': f'{view.user.get_full_name() if view.user else "کاربر مهمان"} فروشگاه را مشاهده کرد'
            })
        
        # مرتب‌سازی فعالیت‌ها بر اساس زمان
        recent_activities.sort(key=lambda x: x['timestamp'], reverse=True)
        recent_activities = recent_activities[:10]
        
        # آمار تعامل
        engagement_rate = 0
        if total_views > 0:
            total_engagements = total_likes + total_comments + total_bookmarks
            engagement_rate = (total_engagements / total_views) * 100
        
        # آمار جغرافیایی (ساده)
        unique_viewers = MarketView.objects.filter(market=market).values('user').distinct().count()
        
        # نمودار آمار هفتگی (7 روز گذشته)
        weekly_stats = []
        for i in range(7):
            date = (timezone.now() - timedelta(days=i)).date()
            day_views = MarketView.objects.filter(
                market=market,
                created_at__date=date
            ).count()
            day_likes = MarketLike.objects.filter(
                market=market,
                is_active=True,
                created_at__date=date
            ).count()
            
            weekly_stats.append({
                'date': date.strftime('%Y-%m-%d'),
                'views': day_views,
                'likes': day_likes,
            })
        
        weekly_stats.reverse()  # از قدیمی به جدید
        
        data = {
            'market_info': {
                'id': market.id,
                'name': market.name,
                'business_id': market.business_id,
                'status': market.status,
                'is_paid': market.is_paid,
                'created_at': market.created_at,
            },
            'overview_stats': {
                'total_views': total_views,
                'total_likes': total_likes,
                'total_comments': total_comments,
                'total_bookmarks': total_bookmarks,
                'unique_viewers': unique_viewers,
                'engagement_rate': round(engagement_rate, 2),
            },
            'daily_stats': {
                'views': today_views,
                'likes': today_likes,
                'comments': today_comments,
            },
            'weekly_stats': {
                'views': week_views,
                'likes': week_likes,
            },
            'monthly_stats': {
                'views': month_views,
                'likes': month_likes,
            },
            'recent_activities': recent_activities,
            'weekly_chart': weekly_stats,
        }
        
        success_response = ApiResponse(
            success=True,
            code=200,
            data=data,
            message='داشبورد فروشگاه دریافت شد'
        )
        
        return Response(success_response, status=status.HTTP_200_OK)


class MarketDashboardListAPIView(views.APIView):
    """
    لیست داشبوردهای فروشگاه‌های کاربر
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, format=None):
        user = request.user
        
        # دریافت فروشگاه‌های کاربر
        markets = Market.objects.filter(user=user).order_by('-created_at')
        
        dashboard_data = []
        for market in markets:
            # آمار سریع برای هر فروشگاه
            total_views = MarketView.objects.filter(market=market).count()
            total_likes = MarketLike.objects.filter(market=market, is_active=True).count()
            total_comments = Comment.objects.filter(
                content_type__model='market',
                object_id=market.id
            ).count()
            total_bookmarks = MarketBookmark.objects.filter(market=market, is_active=True).count()
            
            # آمار امروز
            today = timezone.now().date()
            today_views = MarketView.objects.filter(
                market=market,
                created_at__date=today
            ).count()
            
            dashboard_data.append({
                'market_id': market.id,
                'market_name': market.name,
                'business_id': market.business_id,
                'status': market.status,
                'is_paid': market.is_paid,
                'created_at': market.created_at,
                'total_views': total_views,
                'total_likes': total_likes,
                'total_comments': total_comments,
                'total_bookmarks': total_bookmarks,
                'today_views': today_views,
                'dashboard_url': f'/api/market/dashboard/{market.id}/',
            })
        
        success_response = ApiResponse(
            success=True,
            code=200,
            data=dashboard_data,
            message='لیست داشبوردهای فروشگاه‌ها دریافت شد'
        )
        
        return Response(success_response, status=status.HTTP_200_OK)


class MarketDashboardSummaryAPIView(views.APIView):
    """
    خلاصه کلی داشبورد کاربر
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, format=None):
        user = request.user
        
        # آمار کلی کاربر
        user_markets = Market.objects.filter(user=user)
        total_markets = user_markets.count()
        published_markets = user_markets.filter(status=Market.PUBLISHED).count()
        draft_markets = user_markets.filter(status=Market.DRAFT).count()
        
        # آمار کلی تمام فروشگاه‌های کاربر
        total_views = 0
        total_likes = 0
        total_comments = 0
        total_bookmarks = 0
        
        for market in user_markets:
            total_views += MarketView.objects.filter(market=market).count()
            total_likes += MarketLike.objects.filter(market=market, is_active=True).count()
            total_comments += Comment.objects.filter(
                content_type__model='market',
                object_id=market.id
            ).count()
            total_bookmarks += MarketBookmark.objects.filter(market=market, is_active=True).count()
        
        # آمار امروز
        today = timezone.now().date()
        today_views = 0
        today_likes = 0
        
        for market in user_markets:
            today_views += MarketView.objects.filter(
                market=market,
                created_at__date=today
            ).count()
            today_likes += MarketLike.objects.filter(
                market=market,
                is_active=True,
                created_at__date=today
            ).count()
        
        # محبوب‌ترین فروشگاه
        most_popular_market = None
        max_views = 0
        
        for market in user_markets:
            market_views = MarketView.objects.filter(market=market).count()
            if market_views > max_views:
                max_views = market_views
                most_popular_market = market
        
        # آمار هفتگی
        week_ago = timezone.now() - timedelta(days=7)
        week_views = 0
        week_likes = 0
        
        for market in user_markets:
            week_views += MarketView.objects.filter(
                market=market,
                created_at__gte=week_ago
            ).count()
            week_likes += MarketLike.objects.filter(
                market=market,
                is_active=True,
                created_at__gte=week_ago
            ).count()
        
        data = {
            'user_info': {
                'total_markets': total_markets,
                'published_markets': published_markets,
                'draft_markets': draft_markets,
            },
            'overall_stats': {
                'total_views': total_views,
                'total_likes': total_likes,
                'total_comments': total_comments,
                'total_bookmarks': total_bookmarks,
            },
            'daily_stats': {
                'views': today_views,
                'likes': today_likes,
            },
            'weekly_stats': {
                'views': week_views,
                'likes': week_likes,
            },
            'most_popular_market': {
                'id': most_popular_market.id if most_popular_market else None,
                'name': most_popular_market.name if most_popular_market else None,
                'views': max_views,
            } if most_popular_market else None,
        }
        
        success_response = ApiResponse(
            success=True,
            code=200,
            data=data,
            message='خلاصه داشبورد دریافت شد'
        )
        
        return Response(success_response, status=status.HTTP_200_OK)



