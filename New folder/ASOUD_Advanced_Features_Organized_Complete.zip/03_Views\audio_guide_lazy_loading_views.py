from rest_framework import views, status, permissions
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from django.core.cache import cache
from django.http import Http404, StreamingHttpResponse
import os
import mimetypes

from apps.market.models import Market
from apps.market.models.audio_guide_models import MarketAudioGuide, AudioGuideSegment
from apps.base.utils import ApiResponse


class AudioGuideLazyLoadingAPIView(views.APIView):
    """
    API برای لود تدریجی راهنمای صوتی
    """
    permission_classes = [permissions.AllowAny]

    def get(self, request, market_id, format=None):
        try:
            market = Market.objects.get(id=market_id, status=Market.PUBLISHED)
        except Market.DoesNotExist:
            return Response(
                ApiResponse(
                    success=False,
                    code=404,
                    error="فروشگاه یافت نشد"
                ),
                status=status.HTTP_404_NOT_FOUND
            )
        
        # دریافت راهنمای صوتی
        try:
            audio_guide = MarketAudioGuide.objects.get(market=market, is_active=True)
        except MarketAudioGuide.DoesNotExist:
            return Response(
                ApiResponse(
                    success=False,
                    code=404,
                    error="راهنمای صوتی یافت نشد"
                ),
                status=status.HTTP_404_NOT_FOUND
            )
        
        # کش کلید
        cache_key = f"audio_guide_metadata_{market_id}"
        cached_data = cache.get(cache_key)
        
        if cached_data:
            return Response(cached_data)
        
        # دریافت بخش‌های راهنما
        segments = AudioGuideSegment.objects.filter(
            audio_guide=audio_guide,
            is_active=True
        ).order_by('order')
        
        # ساخت متادیتای راهنما
        segments_data = []
        for segment in segments:
            segments_data.append({
                'id': segment.id,
                'title': segment.title,
                'description': segment.description,
                'order': segment.order,
                'duration': segment.duration,
                'file_size': segment.file_size,
                'audio_url': f'/api/market/audio-guide/{market_id}/segment/{segment.id}/stream/',
                'download_url': f'/api/market/audio-guide/{market_id}/segment/{segment.id}/download/',
            })
        
        data = {
            'audio_guide': {
                'id': audio_guide.id,
                'title': audio_guide.title,
                'description': audio_guide.description,
                'total_duration': audio_guide.total_duration,
                'total_segments': len(segments_data),
                'created_at': audio_guide.created_at,
                'updated_at': audio_guide.updated_at,
            },
            'segments': segments_data,
            'market': {
                'id': market.id,
                'name': market.name,
                'business_id': market.business_id,
            }
        }
        
        # کش کردن نتیجه (30 دقیقه)
        cache.set(cache_key, data, 1800)
        
        success_response = ApiResponse(
            success=True,
            code=200,
            data=data,
            message='متادیتای راهنمای صوتی دریافت شد'
        )
        
        return Response(success_response, status=status.HTTP_200_OK)


class AudioGuideSegmentStreamAPIView(views.APIView):
    """
    API برای استریم بخش‌های راهنمای صوتی
    """
    permission_classes = [permissions.AllowAny]

    def get(self, request, market_id, segment_id, format=None):
        try:
            market = Market.objects.get(id=market_id, status=Market.PUBLISHED)
            audio_guide = MarketAudioGuide.objects.get(market=market, is_active=True)
            segment = AudioGuideSegment.objects.get(
                id=segment_id,
                audio_guide=audio_guide,
                is_active=True
            )
        except (Market.DoesNotExist, MarketAudioGuide.DoesNotExist, AudioGuideSegment.DoesNotExist):
            raise Http404("بخش راهنمای صوتی یافت نشد")
        
        # بررسی وجود فایل
        if not segment.audio_file or not os.path.exists(segment.audio_file.path):
            return Response(
                ApiResponse(
                    success=False,
                    code=404,
                    error="فایل صوتی یافت نشد"
                ),
                status=status.HTTP_404_NOT_FOUND
            )
        
        # تنظیمات استریم
        file_path = segment.audio_file.path
        file_size = os.path.getsize(file_path)
        
        # پشتیبانی از Range requests برای لود تدریجی
        range_header = request.META.get('HTTP_RANGE')
        if range_header:
            # تجزیه Range header
            range_match = range_header.replace('bytes=', '').split('-')
            start = int(range_match[0]) if range_match[0] else 0
            end = int(range_match[1]) if range_match[1] else file_size - 1
            
            # محدود کردن end
            end = min(end, file_size - 1)
            content_length = end - start + 1
            
            # خواندن بخش مورد نظر
            with open(file_path, 'rb') as f:
                f.seek(start)
                content = f.read(content_length)
            
            # تنظیم headers
            response = StreamingHttpResponse(
                [content],
                status=206,  # Partial Content
                content_type=mimetypes.guess_type(file_path)[0] or 'audio/mpeg'
            )
            response['Content-Range'] = f'bytes {start}-{end}/{file_size}'
            response['Accept-Ranges'] = 'bytes'
            response['Content-Length'] = str(content_length)
            
            return response
        else:
            # استریم کامل فایل
            def file_generator():
                with open(file_path, 'rb') as f:
                    while True:
                        chunk = f.read(8192)  # 8KB chunks
                        if not chunk:
                            break
                        yield chunk
            
            response = StreamingHttpResponse(
                file_generator(),
                content_type=mimetypes.guess_type(file_path)[0] or 'audio/mpeg'
            )
            response['Content-Length'] = str(file_size)
            response['Accept-Ranges'] = 'bytes'
            
            return response


class AudioGuideSegmentDownloadAPIView(views.APIView):
    """
    API برای دانلود بخش‌های راهنمای صوتی
    """
    permission_classes = [permissions.AllowAny]

    def get(self, request, market_id, segment_id, format=None):
        try:
            market = Market.objects.get(id=market_id, status=Market.PUBLISHED)
            audio_guide = MarketAudioGuide.objects.get(market=market, is_active=True)
            segment = AudioGuideSegment.objects.get(
                id=segment_id,
                audio_guide=audio_guide,
                is_active=True
            )
        except (Market.DoesNotExist, MarketAudioGuide.DoesNotExist, AudioGuideSegment.DoesNotExist):
            raise Http404("بخش راهنمای صوتی یافت نشد")
        
        # بررسی وجود فایل
        if not segment.audio_file or not os.path.exists(segment.audio_file.path):
            return Response(
                ApiResponse(
                    success=False,
                    code=404,
                    error="فایل صوتی یافت نشد"
                ),
                status=status.HTTP_404_NOT_FOUND
            )
        
        # تنظیمات دانلود
        file_path = segment.audio_file.path
        file_name = f"{segment.title}_{market.business_id}.mp3"
        
        def file_generator():
            with open(file_path, 'rb') as f:
                while True:
                    chunk = f.read(8192)  # 8KB chunks
                    if not chunk:
                        break
                    yield chunk
        
        response = StreamingHttpResponse(
            file_generator(),
            content_type='application/octet-stream'
        )
        response['Content-Disposition'] = f'attachment; filename="{file_name}"'
        response['Content-Length'] = str(segment.file_size)
        
        return response


class AudioGuideProgressAPIView(views.APIView):
    """
    API برای ردیابی پیشرفت گوش دادن به راهنمای صوتی
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, market_id, segment_id, format=None):
        try:
            market = Market.objects.get(id=market_id, status=Market.PUBLISHED)
            audio_guide = MarketAudioGuide.objects.get(market=market, is_active=True)
            segment = AudioGuideSegment.objects.get(
                id=segment_id,
                audio_guide=audio_guide,
                is_active=True
            )
        except (Market.DoesNotExist, MarketAudioGuide.DoesNotExist, AudioGuideSegment.DoesNotExist):
            return Response(
                ApiResponse(
                    success=False,
                    code=404,
                    error="بخش راهنمای صوتی یافت نشد"
                ),
                status=status.HTTP_404_NOT_FOUND
            )
        
        # دریافت داده‌های پیشرفت
        progress_data = request.data
        current_time = progress_data.get('current_time', 0)
        total_time = progress_data.get('total_time', 0)
        is_completed = progress_data.get('is_completed', False)
        
        # ذخیره پیشرفت در کش (می‌تواند در دیتابیس ذخیره شود)
        cache_key = f"audio_progress_{request.user.id}_{market_id}_{segment_id}"
        progress_info = {
            'current_time': current_time,
            'total_time': total_time,
            'progress_percentage': (current_time / total_time * 100) if total_time > 0 else 0,
            'is_completed': is_completed,
            'last_updated': timezone.now().isoformat(),
        }
        
        # کش کردن پیشرفت (24 ساعت)
        cache.set(cache_key, progress_info, 86400)
        
        data = {
            'segment_id': segment_id,
            'progress': progress_info,
        }
        
        success_response = ApiResponse(
            success=True,
            code=200,
            data=data,
            message='پیشرفت ذخیره شد'
        )
        
        return Response(success_response, status=status.HTTP_200_OK)

    def get(self, request, market_id, segment_id, format=None):
        try:
            market = Market.objects.get(id=market_id, status=Market.PUBLISHED)
            audio_guide = MarketAudioGuide.objects.get(market=market, is_active=True)
            segment = AudioGuideSegment.objects.get(
                id=segment_id,
                audio_guide=audio_guide,
                is_active=True
            )
        except (Market.DoesNotExist, MarketAudioGuide.DoesNotExist, AudioGuideSegment.DoesNotExist):
            return Response(
                ApiResponse(
                    success=False,
                    code=404,
                    error="بخش راهنمای صوتی یافت نشد"
                ),
                status=status.HTTP_404_NOT_FOUND
            )
        
        # دریافت پیشرفت ذخیره شده
        cache_key = f"audio_progress_{request.user.id}_{market_id}_{segment_id}"
        progress_info = cache.get(cache_key)
        
        if not progress_info:
            progress_info = {
                'current_time': 0,
                'total_time': 0,
                'progress_percentage': 0,
                'is_completed': False,
                'last_updated': None,
            }
        
        data = {
            'segment_id': segment_id,
            'progress': progress_info,
        }
        
        success_response = ApiResponse(
            success=True,
            code=200,
            data=data,
            message='پیشرفت دریافت شد'
        )
        
        return Response(success_response, status=status.HTTP_200_OK)


class AudioGuideCompleteAPIView(views.APIView):
    """
    API برای تکمیل راهنمای صوتی
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, market_id, format=None):
        try:
            market = Market.objects.get(id=market_id, status=Market.PUBLISHED)
            audio_guide = MarketAudioGuide.objects.get(market=market, is_active=True)
        except (Market.DoesNotExist, MarketAudioGuide.DoesNotExist):
            return Response(
                ApiResponse(
                    success=False,
                    code=404,
                    error="راهنمای صوتی یافت نشد"
                ),
                status=status.HTTP_404_NOT_FOUND
            )
        
        # دریافت تمام بخش‌ها
        segments = AudioGuideSegment.objects.filter(
            audio_guide=audio_guide,
            is_active=True
        ).order_by('order')
        
        # بررسی تکمیل تمام بخش‌ها
        completed_segments = 0
        total_segments = segments.count()
        
        for segment in segments:
            cache_key = f"audio_progress_{request.user.id}_{market_id}_{segment.id}"
            progress_info = cache.get(cache_key)
            if progress_info and progress_info.get('is_completed', False):
                completed_segments += 1
        
        # محاسبه درصد تکمیل
        completion_percentage = (completed_segments / total_segments * 100) if total_segments > 0 else 0
        
        data = {
            'audio_guide_id': audio_guide.id,
            'market_id': market_id,
            'completed_segments': completed_segments,
            'total_segments': total_segments,
            'completion_percentage': round(completion_percentage, 2),
            'is_fully_completed': completed_segments == total_segments,
        }
        
        success_response = ApiResponse(
            success=True,
            code=200,
            data=data,
            message='وضعیت تکمیل راهنمای صوتی دریافت شد'
        )
        
        return Response(success_response, status=status.HTTP_200_OK)



