from django.db.models import Count, Avg, Q
from django.contrib.contenttypes.models import ContentType
from apps.market.models import Market, MarketLike, MarketView, MarketBookmark
from apps.comment.models import Comment
from apps.users.models import User
import math
from typing import List, Dict, Tuple


class MarketRecommendationEngine:
    """
    موتور پیشنهاد فروشگاه‌ها با الگوریتم یادگیری ماشین
    """
    
    def __init__(self):
        self.user_similarity_cache = {}
        self.market_similarity_cache = {}
    
    def get_user_recommendations(self, user: User, limit: int = 10) -> List[Dict]:
        """
        دریافت پیشنهادات برای کاربر بر اساس الگوریتم Collaborative Filtering
        """
        # دریافت فروشگاه‌های لایک شده توسط کاربر
        user_liked_markets = MarketLike.objects.filter(
            user=user,
            is_active=True
        ).values_list('market_id', flat=True)
        
        if not user_liked_markets:
            # اگر کاربر هیچ لایکی نداشته، فروشگاه‌های محبوب را پیشنهاد بده
            return self.get_popular_markets(limit)
        
        # یافتن کاربران مشابه
        similar_users = self.find_similar_users(user, user_liked_markets)
        
        # دریافت پیشنهادات از کاربران مشابه
        recommendations = self.get_recommendations_from_similar_users(
            user, similar_users, user_liked_markets, limit
        )
        
        return recommendations
    
    def find_similar_users(self, target_user: User, user_liked_markets: List[int]) -> List[Tuple[User, float]]:
        """
        یافتن کاربران مشابه بر اساس شباهت در لایک‌ها
        """
        if target_user.id in self.user_similarity_cache:
            return self.user_similarity_cache[target_user.id]
        
        # دریافت تمام کاربرانی که حداقل یکی از فروشگاه‌های لایک شده توسط کاربر هدف را لایک کرده‌اند
        similar_users_data = MarketLike.objects.filter(
            market_id__in=user_liked_markets,
            is_active=True
        ).exclude(user=target_user).values('user_id').annotate(
            common_likes=Count('market_id')
        ).order_by('-common_likes')
        
        similar_users = []
        for data in similar_users_data:
            user_id = data['user_id']
            common_likes = data['common_likes']
            
            # محاسبه ضریب شباهت (Jaccard Similarity)
            other_user_likes = MarketLike.objects.filter(
                user_id=user_id,
                is_active=True
            ).values_list('market_id', flat=True)
            
            union_size = len(set(user_liked_markets) | set(other_user_likes))
            similarity = common_likes / union_size if union_size > 0 else 0
            
            if similarity > 0.1:  # حداقل شباهت 10%
                try:
                    user = User.objects.get(id=user_id)
                    similar_users.append((user, similarity))
                except User.DoesNotExist:
                    continue
        
        # مرتب‌سازی بر اساس شباهت
        similar_users.sort(key=lambda x: x[1], reverse=True)
        
        # کش کردن نتیجه
        self.user_similarity_cache[target_user.id] = similar_users[:20]  # حداکثر 20 کاربر مشابه
        
        return similar_users[:20]
    
    def get_recommendations_from_similar_users(
        self, 
        target_user: User, 
        similar_users: List[Tuple[User, float]], 
        user_liked_markets: List[int], 
        limit: int
    ) -> List[Dict]:
        """
        دریافت پیشنهادات از کاربران مشابه
        """
        market_scores = {}
        
        for similar_user, similarity in similar_users:
            # دریافت فروشگاه‌های لایک شده توسط کاربر مشابه
            similar_user_likes = MarketLike.objects.filter(
                user=similar_user,
                is_active=True
            ).exclude(market_id__in=user_liked_markets).values_list('market_id', flat=True)
            
            # محاسبه امتیاز برای هر فروشگاه
            for market_id in similar_user_likes:
                if market_id not in market_scores:
                    market_scores[market_id] = 0
                market_scores[market_id] += similarity
        
        # مرتب‌سازی بر اساس امتیاز
        sorted_markets = sorted(market_scores.items(), key=lambda x: x[1], reverse=True)
        
        # دریافت اطلاعات فروشگاه‌ها
        recommendations = []
        for market_id, score in sorted_markets[:limit]:
            try:
                market = Market.objects.get(id=market_id, status=Market.PUBLISHED)
                recommendations.append({
                    'market_id': market.id,
                    'market_name': market.name,
                    'business_id': market.business_id,
                    'score': round(score, 3),
                    'reason': 'بر اساس علایق کاربران مشابه',
                    'sub_category': market.sub_category.title if market.sub_category else None,
                    'logo_url': market.logo_img.url if market.logo_img else None,
                })
            except Market.DoesNotExist:
                continue
        
        return recommendations
    
    def get_popular_markets(self, limit: int = 10) -> List[Dict]:
        """
        دریافت فروشگاه‌های محبوب
        """
        popular_markets = Market.objects.filter(
            status=Market.PUBLISHED
        ).annotate(
            total_likes=Count('liked_by', filter=Q(liked_by__is_active=True)),
            total_views=Count('viewed_by'),
            total_comments=Count('comments'),
        ).order_by('-total_likes', '-total_views')[:limit]
        
        recommendations = []
        for market in popular_markets:
            recommendations.append({
                'market_id': market.id,
                'market_name': market.name,
                'business_id': market.business_id,
                'score': market.total_likes + market.total_views * 0.1,
                'reason': 'فروشگاه محبوب',
                'sub_category': market.sub_category.title if market.sub_category else None,
                'logo_url': market.logo_img.url if market.logo_img else None,
                'stats': {
                    'likes': market.total_likes,
                    'views': market.total_views,
                    'comments': market.total_comments,
                }
            })
        
        return recommendations
    
    def get_content_based_recommendations(self, user: User, limit: int = 10) -> List[Dict]:
        """
        پیشنهادات بر اساس محتوا (Content-Based Filtering)
        """
        # دریافت دسته‌بندی‌های مورد علاقه کاربر
        user_preferences = self.get_user_category_preferences(user)
        
        if not user_preferences:
            return self.get_popular_markets(limit)
        
        # یافتن فروشگاه‌های مشابه در دسته‌بندی‌های مورد علاقه
        recommendations = []
        for category_id, preference_score in user_preferences.items():
            similar_markets = Market.objects.filter(
                sub_category_id=category_id,
                status=Market.PUBLISHED
            ).exclude(
                id__in=MarketLike.objects.filter(
                    user=user,
                    is_active=True
                ).values_list('market_id', flat=True)
            ).annotate(
                total_likes=Count('liked_by', filter=Q(liked_by__is_active=True)),
                total_views=Count('viewed_by'),
            ).order_by('-total_likes', '-total_views')[:5]
            
            for market in similar_markets:
                score = preference_score * (market.total_likes + market.total_views * 0.1)
                recommendations.append({
                    'market_id': market.id,
                    'market_name': market.name,
                    'business_id': market.business_id,
                    'score': round(score, 3),
                    'reason': f'مشابه دسته‌بندی {market.sub_category.title}',
                    'sub_category': market.sub_category.title if market.sub_category else None,
                    'logo_url': market.logo_img.url if market.logo_img else None,
                })
        
        # مرتب‌سازی و محدود کردن
        recommendations.sort(key=lambda x: x['score'], reverse=True)
        return recommendations[:limit]
    
    def get_user_category_preferences(self, user: User) -> Dict[int, float]:
        """
        دریافت ترجیحات دسته‌بندی کاربر
        """
        # دریافت دسته‌بندی‌های فروشگاه‌های لایک شده
        liked_categories = MarketLike.objects.filter(
            user=user,
            is_active=True
        ).values('market__sub_category_id').annotate(
            count=Count('market__sub_category_id')
        ).order_by('-count')
        
        preferences = {}
        total_likes = sum(item['count'] for item in liked_categories)
        
        for item in liked_categories:
            category_id = item['market__sub_category_id']
            count = item['count']
            if category_id and total_likes > 0:
                preferences[category_id] = count / total_likes
        
        return preferences
    
    def get_hybrid_recommendations(self, user: User, limit: int = 10) -> List[Dict]:
        """
        پیشنهادات ترکیبی (Hybrid Recommendation)
        """
        # دریافت پیشنهادات از هر دو روش
        collaborative_recs = self.get_user_recommendations(user, limit // 2)
        content_based_recs = self.get_content_based_recommendations(user, limit // 2)
        
        # ترکیب و رتبه‌بندی مجدد
        all_recommendations = {}
        
        # اضافه کردن پیشنهادات collaborative
        for rec in collaborative_recs:
            market_id = rec['market_id']
            if market_id not in all_recommendations:
                all_recommendations[market_id] = rec.copy()
                all_recommendations[market_id]['score'] *= 0.7  # وزن کمتر
            else:
                all_recommendations[market_id]['score'] += rec['score'] * 0.7
        
        # اضافه کردن پیشنهادات content-based
        for rec in content_based_recs:
            market_id = rec['market_id']
            if market_id not in all_recommendations:
                all_recommendations[market_id] = rec.copy()
                all_recommendations[market_id]['score'] *= 0.3  # وزن کمتر
            else:
                all_recommendations[market_id]['score'] += rec['score'] * 0.3
        
        # مرتب‌سازی و بازگرداندن
        sorted_recommendations = sorted(
            all_recommendations.values(), 
            key=lambda x: x['score'], 
            reverse=True
        )
        
        return sorted_recommendations[:limit]
    
    def get_trending_markets(self, limit: int = 10) -> List[Dict]:
        """
        دریافت فروشگاه‌های ترند
        """
        from django.utils import timezone
        from datetime import timedelta
        
        # فروشگاه‌های محبوب در 7 روز گذشته
        week_ago = timezone.now() - timedelta(days=7)
        
        trending_markets = Market.objects.filter(
            status=Market.PUBLISHED,
            liked_by__created_at__gte=week_ago
        ).annotate(
            recent_likes=Count('liked_by', filter=Q(
                liked_by__is_active=True,
                liked_by__created_at__gte=week_ago
            )),
            total_likes=Count('liked_by', filter=Q(liked_by__is_active=True)),
            total_views=Count('viewed_by'),
        ).order_by('-recent_likes', '-total_likes')[:limit]
        
        recommendations = []
        for market in trending_markets:
            # محاسبه امتیاز ترند
            trend_score = market.recent_likes * 2 + market.total_likes * 0.5 + market.total_views * 0.1
            
            recommendations.append({
                'market_id': market.id,
                'market_name': market.name,
                'business_id': market.business_id,
                'score': round(trend_score, 3),
                'reason': 'فروشگاه ترند',
                'sub_category': market.sub_category.title if market.sub_category else None,
                'logo_url': market.logo_img.url if market.logo_img else None,
                'stats': {
                    'recent_likes': market.recent_likes,
                    'total_likes': market.total_likes,
                    'total_views': market.total_views,
                }
            })
        
        return recommendations



