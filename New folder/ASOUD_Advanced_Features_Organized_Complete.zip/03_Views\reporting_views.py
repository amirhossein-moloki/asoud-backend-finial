from rest_framework import views, status, permissions
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from django.db.models import Count, Q, Avg, Sum
from django.utils import timezone
from datetime import timedelta, datetime
from django.core.cache import cache
import json

from apps.market.models import Market, MarketLike, MarketView, MarketBookmark, MarketReport
from apps.comment.models import Comment
from apps.market.models.analytics_models import MarketAnalytics, MarketEngagementLog
from apps.base.utils import ApiResponse


class MarketReportingAPIView(views.APIView):
    """
    API برای گزارش‌گیری فروشگاه‌ها
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, market_id, format=None):
        market = get_object_or_404(Market, id=market_id, user=request.user)
        
        # پارامترهای گزارش
        report_type = request.GET.get('type', 'overview')  # overview, detailed, engagement, traffic
        period = request.GET.get('period', '7d')  # 1d, 7d, 30d, 90d, 1y
        format_type = request.GET.get('format', 'json')  # json, csv
        
        # کش کلید
        cache_key = f"market_report_{market_id}_{report_type}_{period}_{format_type}"
        cached_data = cache.get(cache_key)
        
        if cached_data:
            return Response(cached_data)
        
        # محاسبه بازه زمانی
        end_date = timezone.now()
        if period == '1d':
            start_date = end_date - timedelta(days=1)
        elif period == '7d':
            start_date = end_date - timedelta(days=7)
        elif period == '30d':
            start_date = end_date - timedelta(days=30)
        elif period == '90d':
            start_date = end_date - timedelta(days=90)
        elif period == '1y':
            start_date = end_date - timedelta(days=365)
        else:
            start_date = end_date - timedelta(days=7)
        
        # تولید گزارش بر اساس نوع
        if report_type == 'overview':
            data = self._generate_overview_report(market, start_date, end_date)
        elif report_type == 'detailed':
            data = self._generate_detailed_report(market, start_date, end_date)
        elif report_type == 'engagement':
            data = self._generate_engagement_report(market, start_date, end_date)
        elif report_type == 'traffic':
            data = self._generate_traffic_report(market, start_date, end_date)
        else:
            data = self._generate_overview_report(market, start_date, end_date)
        
        # اضافه کردن متادیتا
        data['metadata'] = {
            'market_id': market.id,
            'market_name': market.name,
            'report_type': report_type,
            'period': period,
            'start_date': start_date.isoformat(),
            'end_date': end_date.isoformat(),
            'generated_at': timezone.now().isoformat(),
        }
        
        # کش کردن نتیجه (15 دقیقه)
        cache.set(cache_key, data, 900)
        
        success_response = ApiResponse(
            success=True,
            code=200,
            data=data,
            message=f'گزارش {report_type} دریافت شد'
        )
        
        return Response(success_response, status=status.HTTP_200_OK)
    
    def _generate_overview_report(self, market, start_date, end_date):
        """تولید گزارش کلی"""
        # آمار کلی
        total_views = MarketView.objects.filter(
            market=market,
            created_at__gte=start_date,
            created_at__lte=end_date
        ).count()
        
        total_likes = MarketLike.objects.filter(
            market=market,
            is_active=True,
            created_at__gte=start_date,
            created_at__lte=end_date
        ).count()
        
        total_comments = Comment.objects.filter(
            content_type__model='market',
            object_id=market.id,
            created_at__gte=start_date,
            created_at__lte=end_date
        ).count()
        
        total_bookmarks = MarketBookmark.objects.filter(
            market=market,
            is_active=True,
            created_at__gte=start_date,
            created_at__lte=end_date
        ).count()
        
        # آمار روزانه
        daily_stats = []
        current_date = start_date.date()
        end_date_only = end_date.date()
        
        while current_date <= end_date_only:
            day_views = MarketView.objects.filter(
                market=market,
                created_at__date=current_date
            ).count()
            
            day_likes = MarketLike.objects.filter(
                market=market,
                is_active=True,
                created_at__date=current_date
            ).count()
            
            day_comments = Comment.objects.filter(
                content_type__model='market',
                object_id=market.id,
                created_at__date=current_date
            ).count()
            
            daily_stats.append({
                'date': current_date.isoformat(),
                'views': day_views,
                'likes': day_likes,
                'comments': day_comments,
            })
            
            current_date += timedelta(days=1)
        
        # محاسبه نرخ تعامل
        engagement_rate = 0
        if total_views > 0:
            total_engagements = total_likes + total_comments + total_bookmarks
            engagement_rate = (total_engagements / total_views) * 100
        
        return {
            'overview': {
                'total_views': total_views,
                'total_likes': total_likes,
                'total_comments': total_comments,
                'total_bookmarks': total_bookmarks,
                'engagement_rate': round(engagement_rate, 2),
            },
            'daily_stats': daily_stats,
        }
    
    def _generate_detailed_report(self, market, start_date, end_date):
        """تولید گزارش تفصیلی"""
        # آمار کلی
        overview = self._generate_overview_report(market, start_date, end_date)
        
        # آمار کاربران منحصر به فرد
        unique_viewers = MarketView.objects.filter(
            market=market,
            created_at__gte=start_date,
            created_at__lte=end_date
        ).values('user').distinct().count()
        
        # آمار جغرافیایی (ساده)
        location_stats = MarketView.objects.filter(
            market=market,
            created_at__gte=start_date,
            created_at__lte=end_date
        ).values('user__city').annotate(
            count=Count('id')
        ).order_by('-count')[:10]
        
        # آمار ساعتی (ساعات پیک)
        hourly_stats = []
        for hour in range(24):
            hour_views = MarketView.objects.filter(
                market=market,
                created_at__gte=start_date,
                created_at__lte=end_date,
                created_at__hour=hour
            ).count()
            
            hourly_stats.append({
                'hour': hour,
                'views': hour_views,
            })
        
        # آمار دستگاه‌ها (شبیه‌سازی)
        device_stats = [
            {'device': 'mobile', 'count': int(overview['overview']['total_views'] * 0.7)},
            {'device': 'desktop', 'count': int(overview['overview']['total_views'] * 0.25)},
            {'device': 'tablet', 'count': int(overview['overview']['total_views'] * 0.05)},
        ]
        
        return {
            **overview,
            'detailed_stats': {
                'unique_viewers': unique_viewers,
                'location_stats': list(location_stats),
                'hourly_stats': hourly_stats,
                'device_stats': device_stats,
            }
        }
    
    def _generate_engagement_report(self, market, start_date, end_date):
        """تولید گزارش تعامل"""
        # آمار تعامل
        likes = MarketLike.objects.filter(
            market=market,
            is_active=True,
            created_at__gte=start_date,
            created_at__lte=end_date
        )
        
        comments = Comment.objects.filter(
            content_type__model='market',
            object_id=market.id,
            created_at__gte=start_date,
            created_at__lte=end_date
        )
        
        bookmarks = MarketBookmark.objects.filter(
            market=market,
            is_active=True,
            created_at__gte=start_date,
            created_at__lte=end_date
        )
        
        # آمار کاربران فعال
        active_users = set()
        for like in likes:
            if like.user:
                active_users.add(like.user.id)
        for comment in comments:
            if comment.creator:
                active_users.add(comment.creator.id)
        for bookmark in bookmarks:
            if bookmark.user:
                active_users.add(bookmark.user.id)
        
        # آمار تعامل روزانه
        engagement_daily = []
        current_date = start_date.date()
        end_date_only = end_date.date()
        
        while current_date <= end_date_only:
            day_likes = likes.filter(created_at__date=current_date).count()
            day_comments = comments.filter(created_at__date=current_date).count()
            day_bookmarks = bookmarks.filter(created_at__date=current_date).count()
            
            engagement_daily.append({
                'date': current_date.isoformat(),
                'likes': day_likes,
                'comments': day_comments,
                'bookmarks': day_bookmarks,
                'total_engagement': day_likes + day_comments + day_bookmarks,
            })
            
            current_date += timedelta(days=1)
        
        # محاسبه نرخ تعامل
        total_views = MarketView.objects.filter(
            market=market,
            created_at__gte=start_date,
            created_at__lte=end_date
        ).count()
        
        total_engagements = likes.count() + comments.count() + bookmarks.count()
        engagement_rate = (total_engagements / total_views * 100) if total_views > 0 else 0
        
        return {
            'engagement_summary': {
                'total_likes': likes.count(),
                'total_comments': comments.count(),
                'total_bookmarks': bookmarks.count(),
                'total_engagements': total_engagements,
                'active_users': len(active_users),
                'engagement_rate': round(engagement_rate, 2),
            },
            'engagement_daily': engagement_daily,
        }
    
    def _generate_traffic_report(self, market, start_date, end_date):
        """تولید گزارش ترافیک"""
        # آمار ترافیک
        views = MarketView.objects.filter(
            market=market,
            created_at__gte=start_date,
            created_at__lte=end_date
        )
        
        # آمار روزانه ترافیک
        traffic_daily = []
        current_date = start_date.date()
        end_date_only = end_date.date()
        
        while current_date <= end_date_only:
            day_views = views.filter(created_at__date=current_date).count()
            unique_day_viewers = views.filter(created_at__date=current_date).values('user').distinct().count()
            
            traffic_daily.append({
                'date': current_date.isoformat(),
                'total_views': day_views,
                'unique_viewers': unique_day_viewers,
                'views_per_user': round(day_views / unique_day_viewers, 2) if unique_day_viewers > 0 else 0,
            })
            
            current_date += timedelta(days=1)
        
        # آمار ساعتی ترافیک
        traffic_hourly = []
        for hour in range(24):
            hour_views = views.filter(created_at__hour=hour).count()
            traffic_hourly.append({
                'hour': hour,
                'views': hour_views,
            })
        
        # آمار منابع ترافیک (شبیه‌سازی)
        traffic_sources = [
            {'source': 'direct', 'count': int(views.count() * 0.4)},
            {'source': 'search', 'count': int(views.count() * 0.3)},
            {'source': 'social', 'count': int(views.count() * 0.2)},
            {'source': 'referral', 'count': int(views.count() * 0.1)},
        ]
        
        return {
            'traffic_summary': {
                'total_views': views.count(),
                'unique_viewers': views.values('user').distinct().count(),
                'average_views_per_user': round(views.count() / views.values('user').distinct().count(), 2) if views.values('user').distinct().count() > 0 else 0,
            },
            'traffic_daily': traffic_daily,
            'traffic_hourly': traffic_hourly,
            'traffic_sources': traffic_sources,
        }


class MarketReportExportAPIView(views.APIView):
    """
    API برای صادرات گزارش‌ها
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, market_id, format=None):
        market = get_object_or_404(Market, id=market_id, user=request.user)
        
        export_format = request.GET.get('format', 'csv')  # csv, json, xlsx
        report_type = request.GET.get('type', 'overview')
        period = request.GET.get('period', '7d')
        
        # تولید گزارش
        reporting_api = MarketReportingAPIView()
        report_data = reporting_api._generate_overview_report(
            market, 
            timezone.now() - timedelta(days=7), 
            timezone.now()
        )
        
        if export_format == 'csv':
            # تولید CSV
            import csv
            from django.http import HttpResponse
            
            response = HttpResponse(content_type='text/csv')
            response['Content-Disposition'] = f'attachment; filename="market_report_{market_id}_{report_type}.csv"'
            
            writer = csv.writer(response)
            
            # نوشتن هدر
            writer.writerow(['Date', 'Views', 'Likes', 'Comments'])
            
            # نوشتن داده‌ها
            for day in report_data['daily_stats']:
                writer.writerow([
                    day['date'],
                    day['views'],
                    day['likes'],
                    day['comments']
                ])
            
            return response
        
        elif export_format == 'json':
            # تولید JSON
            from django.http import JsonResponse
            return JsonResponse(report_data, safe=False)
        
        else:
            return Response(
                ApiResponse(
                    success=False,
                    code=400,
                    error="فرمت صادرات پشتیبانی نمی‌شود"
                ),
                status=status.HTTP_400_BAD_REQUEST
            )


class MarketReportComparisonAPIView(views.APIView):
    """
    API برای مقایسه گزارش‌های فروشگاه‌ها
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, format=None):
        user = request.user
        
        # دریافت فروشگاه‌های کاربر
        markets = Market.objects.filter(user=user, status=Market.PUBLISHED)
        
        # پارامترها
        period = request.GET.get('period', '7d')
        metric = request.GET.get('metric', 'views')  # views, likes, comments, engagement
        
        # محاسبه بازه زمانی
        end_date = timezone.now()
        if period == '1d':
            start_date = end_date - timedelta(days=1)
        elif period == '7d':
            start_date = end_date - timedelta(days=7)
        elif period == '30d':
            start_date = end_date - timedelta(days=30)
        else:
            start_date = end_date - timedelta(days=7)
        
        # مقایسه فروشگاه‌ها
        comparison_data = []
        for market in markets:
            if metric == 'views':
                value = MarketView.objects.filter(
                    market=market,
                    created_at__gte=start_date,
                    created_at__lte=end_date
                ).count()
            elif metric == 'likes':
                value = MarketLike.objects.filter(
                    market=market,
                    is_active=True,
                    created_at__gte=start_date,
                    created_at__lte=end_date
                ).count()
            elif metric == 'comments':
                value = Comment.objects.filter(
                    content_type__model='market',
                    object_id=market.id,
                    created_at__gte=start_date,
                    created_at__lte=end_date
                ).count()
            elif metric == 'engagement':
                views = MarketView.objects.filter(
                    market=market,
                    created_at__gte=start_date,
                    created_at__lte=end_date
                ).count()
                likes = MarketLike.objects.filter(
                    market=market,
                    is_active=True,
                    created_at__gte=start_date,
                    created_at__lte=end_date
                ).count()
                comments = Comment.objects.filter(
                    content_type__model='market',
                    object_id=market.id,
                    created_at__gte=start_date,
                    created_at__lte=end_date
                ).count()
                value = (likes + comments) / views * 100 if views > 0 else 0
            else:
                value = 0
            
            comparison_data.append({
                'market_id': market.id,
                'market_name': market.name,
                'business_id': market.business_id,
                'metric_value': value,
                'metric_type': metric,
            })
        
        # مرتب‌سازی بر اساس مقدار
        comparison_data.sort(key=lambda x: x['metric_value'], reverse=True)
        
        data = {
            'comparison_data': comparison_data,
            'metric': metric,
            'period': period,
            'start_date': start_date.isoformat(),
            'end_date': end_date.isoformat(),
        }
        
        success_response = ApiResponse(
            success=True,
            code=200,
            data=data,
            message='مقایسه فروشگاه‌ها دریافت شد'
        )
        
        return Response(success_response, status=status.HTTP_200_OK)



