from django.urls import path, include
from apps.market.views import (
    analytics_views,
    notification_views,
    dashboard_views,
    ml_views,
    mobile_optimized_views,
    audio_guide_lazy_loading_views,
    reporting_views,
    performance_optimization_views,
    market_like_views,
    market_share_views,
    market_view_views,
    audio_guide_views,
)

# URL patterns for advanced features
urlpatterns = [
    # Analytics URLs
    path('analytics/', include([
        path('market/<int:market_id>/', analytics_views.MarketAnalyticsAPIView.as_view(), name='market_analytics'),
        path('market/<int:market_id>/traffic/', analytics_views.MarketTrafficAPIView.as_view(), name='market_traffic'),
        path('market/<int:market_id>/engagement/', analytics_views.MarketEngagementAPIView.as_view(), name='market_engagement'),
        path('market/<int:market_id>/geographic/', analytics_views.MarketGeographicAPIView.as_view(), name='market_geographic'),
        path('market/<int:market_id>/device/', analytics_views.MarketDeviceAPIView.as_view(), name='market_device'),
        path('market/<int:market_id>/hourly/', analytics_views.MarketHourlyAPIView.as_view(), name='market_hourly'),
        path('market/<int:market_id>/daily/', analytics_views.MarketDailyAPIView.as_view(), name='market_daily'),
        path('market/<int:market_id>/weekly/', analytics_views.MarketWeeklyAPIView.as_view(), name='market_weekly'),
        path('market/<int:market_id>/monthly/', analytics_views.MarketMonthlyAPIView.as_view(), name='market_monthly'),
        path('market/<int:market_id>/yearly/', analytics_views.MarketYearlyAPIView.as_view(), name='market_yearly'),
        path('market/<int:market_id>/comparison/', analytics_views.MarketComparisonAPIView.as_view(), name='market_comparison'),
        path('market/<int:market_id>/export/', analytics_views.MarketAnalyticsExportAPIView.as_view(), name='market_analytics_export'),
    ])),

    # Notification URLs
    path('notifications/', include([
        path('user/', notification_views.UserNotificationListAPIView.as_view(), name='user_notifications'),
        path('user/unread/', notification_views.UserUnreadNotificationAPIView.as_view(), name='user_unread_notifications'),
        path('user/mark-as-read/', notification_views.MarkNotificationAsReadAPIView.as_view(), name='mark_notification_read'),
        path('user/mark-all-read/', notification_views.MarkAllNotificationsAsReadAPIView.as_view(), name='mark_all_notifications_read'),
        path('user/settings/', notification_views.UserNotificationSettingsAPIView.as_view(), name='user_notification_settings'),
        path('market/<int:market_id>/', notification_views.MarketNotificationListAPIView.as_view(), name='market_notifications'),
        path('market/<int:market_id>/send/', notification_views.SendMarketNotificationAPIView.as_view(), name='send_market_notification'),
        path('market/<int:market_id>/stats/', notification_views.MarketNotificationStatsAPIView.as_view(), name='market_notification_stats'),
        path('admin/', notification_views.AdminNotificationManagementAPIView.as_view(), name='admin_notification_management'),
    ])),

    # Dashboard URLs
    path('dashboard/', include([
        path('market/<int:market_id>/', dashboard_views.MarketDashboardAPIView.as_view(), name='market_dashboard'),
        path('list/', dashboard_views.MarketDashboardListAPIView.as_view(), name='market_dashboard_list'),
        path('summary/', dashboard_views.MarketDashboardSummaryAPIView.as_view(), name='market_dashboard_summary'),
    ])),

    # Machine Learning URLs
    path('ml/', include([
        path('recommendations/', ml_views.MarketRecommendationAPIView.as_view(), name='market_recommendations'),
        path('similar/<int:market_id>/', ml_views.MarketSimilarityAPIView.as_view(), name='market_similarity'),
        path('trending/', ml_views.MarketTrendingAPIView.as_view(), name='market_trending'),
        path('popular/', ml_views.MarketPopularAPIView.as_view(), name='market_popular'),
        path('stats/', ml_views.MarketRecommendationStatsAPIView.as_view(), name='market_recommendation_stats'),
    ])),

    # Mobile Optimization URLs
    path('mobile/', include([
        path('markets/', mobile_optimized_views.MobileMarketListAPIView.as_view(), name='mobile_market_list'),
        path('markets/<int:market_id>/', mobile_optimized_views.MobileMarketDetailAPIView.as_view(), name='mobile_market_detail'),
        path('markets/icons/<int:market_id>/', mobile_optimized_views.MobileMarketIconsAPIView.as_view(), name='mobile_market_icons'),
        path('search/', mobile_optimized_views.MobileMarketSearchAPIView.as_view(), name='mobile_market_search'),
        path('trending/', mobile_optimized_views.MobileMarketTrendingAPIView.as_view(), name='mobile_market_trending'),
    ])),

    # Audio Guide URLs
    path('audio-guide/', include([
        path('market/<int:market_id>/', audio_guide_lazy_loading_views.AudioGuideLazyLoadingAPIView.as_view(), name='audio_guide_lazy_loading'),
        path('market/<int:market_id>/segment/<int:segment_id>/stream/', audio_guide_lazy_loading_views.AudioGuideSegmentStreamAPIView.as_view(), name='audio_guide_segment_stream'),
        path('market/<int:market_id>/segment/<int:segment_id>/download/', audio_guide_lazy_loading_views.AudioGuideSegmentDownloadAPIView.as_view(), name='audio_guide_segment_download'),
        path('market/<int:market_id>/segment/<int:segment_id>/progress/', audio_guide_lazy_loading_views.AudioGuideProgressAPIView.as_view(), name='audio_guide_progress'),
        path('market/<int:market_id>/complete/', audio_guide_lazy_loading_views.AudioGuideCompleteAPIView.as_view(), name='audio_guide_complete'),
    ])),

    # Reporting URLs
    path('reporting/', include([
        path('market/<int:market_id>/', reporting_views.MarketReportingAPIView.as_view(), name='market_reporting'),
        path('market/<int:market_id>/export/', reporting_views.MarketReportExportAPIView.as_view(), name='market_report_export'),
        path('comparison/', reporting_views.MarketReportComparisonAPIView.as_view(), name='market_report_comparison'),
    ])),

    # Performance Optimization URLs
    path('performance/', include([
        path('monitoring/', performance_optimization_views.PerformanceMonitoringAPIView.as_view(), name='performance_monitoring'),
        path('optimization/', performance_optimization_views.QueryOptimizationAPIView.as_view(), name='query_optimization'),
        path('cache/', performance_optimization_views.CacheManagementAPIView.as_view(), name='cache_management'),
        path('database/', performance_optimization_views.DatabaseOptimizationAPIView.as_view(), name='database_optimization'),
    ])),

    # Market Icons URLs
    path('icons/', include([
        path('like/<int:market_id>/', market_like_views.MarketLikeAPIView.as_view(), name='market_like'),
        path('share/<int:market_id>/', market_share_views.MarketShareAPIView.as_view(), name='market_share'),
        path('view/<int:market_id>/', market_view_views.MarketViewAPIView.as_view(), name='market_view'),
        path('view/<int:market_id>/stats/', market_view_views.MarketViewStatsAPIView.as_view(), name='market_view_stats'),
        path('audio-guide/<int:market_id>/', audio_guide_views.AudioGuideAPIView.as_view(), name='market_audio_guide'),
    ])),
]



