# apps/market/serializers/owner_serializers.py
from rest_framework import serializers
from apps.market.models import Market, MarketSlider
from apps.category.models import Group, Category, SubCategory


class MarketSliderListSerializer(serializers.ModelSerializer):
    class Meta:
        model = MarketSlider
        fields = [
            'id', 'image', 'url', 'order', 'title', 'description', 'is_active'
        ]


class MarketListSerializer(serializers.ModelSerializer):
    # ... existing fields ...
    market_sliders = MarketSliderListSerializer(many=True, read_only=True)
    
    class Meta:
        model = Market
        fields = [
            # ... existing fields ...
            'market_sliders',
            # ... rest of fields ...
        ]


# ... rest of existing serializers ...