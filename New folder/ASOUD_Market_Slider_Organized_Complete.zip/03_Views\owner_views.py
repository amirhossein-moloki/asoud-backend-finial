# apps/market/views/owner_views.py
from rest_framework import views, status, permissions
from rest_framework.response import Response
from utils.response import ApiResponse
from apps.market.models import Market, MarketSlider
from apps.market.serializers.owner_serializers import MarketSliderListSerializer


class MarketSliderAPIView(views.APIView):
    permission_classes = [permissions.IsAuthenticated]  # Added permission

    def get(self, request, pk):
        try:
            market_obj = Market.objects.get(id=pk)
        except Market.DoesNotExist:
            response = ApiResponse(
                success=False,
                code=404,
                error={
                    'code': 'market_not_found',
                    'detail': 'Market not found in the database',
                }
            )
            return Response(response)

        slider_list = MarketSlider.objects.filter(
            market=market_obj,
        ).order_by('order')

        serializer = MarketSliderListSerializer(
            slider_list,
            many=True,
            context={"request": request},
        )

        success_response = ApiResponse(
            success=True,
            code=200,
            data=serializer.data,
            message='Data retrieved successfully'
        )

        return Response(success_response)

    def post(self, request, pk):
        slider_img = request.FILES.get('slider_img')
        url = request.data.get('url')
        order = request.data.get('order', 0)
        title = request.data.get('title')
        description = request.data.get('description')
        is_active = request.data.get('is_active', True)

        try:
            market_obj = Market.objects.get(id=pk)
        except Market.DoesNotExist:
            response = ApiResponse(
                success=False,
                code=404,
                error={
                    'code': 'market_not_found',
                    'detail': 'Market not found in the database',
                }
            )
            return Response(response)

        market_slider_img = MarketSlider.objects.create(
            market=market_obj,
            image=slider_img,
            url=url,
            order=order,
            title=title,
            description=description,
            is_active=is_active
        )

        data = {
            'slider_img': request.build_absolute_uri(market_slider_img.image.url),
            'url': market_slider_img.url,
            'order': market_slider_img.order,
            'title': market_slider_img.title,
            'description': market_slider_img.description,
            'is_active': market_slider_img.is_active,
        }

        success_response = ApiResponse(
            success=True,
            code=200,
            data=data,
            message='New slider has been created successfully'
        )

        return Response(success_response)

    def delete(self, request, pk):
        try:
            market_slider_obj = MarketSlider.objects.get(id=pk)
        except MarketSlider.DoesNotExist:
            response = ApiResponse(
                success=False,
                code=404,
                error={
                    'code': 'market_slider_not_found',
                    'detail': 'MarketSlider not found in the database',
                }
            )
            return Response(response)

        # Delete the file
        market_slider_obj.delete()

        success_response = ApiResponse(
            success=True,
            code=200,
            data={},
            message='MarketSlider removed successfully',
        )

        return Response(success_response)

    def patch(self, request, pk):
        try:
            market_slider_obj = MarketSlider.objects.get(id=pk)
        except MarketSlider.DoesNotExist:
            response = ApiResponse(
                success=False,
                code=404,
                error={
                    'code': 'market_slider_not_found',
                    'detail': 'MarketSlider not found in the database',
                }
            )
            return Response(response)

        # Update the image if provided in the request
        slider_img = request.FILES.get('slider_img')
        if slider_img:
            market_slider_obj.image = slider_img

        # Update other fields
        market_slider_obj.url = request.data.get('url', market_slider_obj.url)
        market_slider_obj.order = request.data.get('order', market_slider_obj.order)
        market_slider_obj.title = request.data.get('title', market_slider_obj.title)
        market_slider_obj.description = request.data.get('description', market_slider_obj.description)
        market_slider_obj.is_active = request.data.get('is_active', market_slider_obj.is_active)

        market_slider_obj.save()

        data = {
            'slider_img': request.build_absolute_uri(market_slider_obj.image.url),
            'url': market_slider_obj.url,
            'order': market_slider_obj.order,
            'title': market_slider_obj.title,
            'description': market_slider_obj.description,
            'is_active': market_slider_obj.is_active,
        }

        success_response = ApiResponse(
            success=True,
            code=200,
            data=data,
            message='MarketSlider updated successfully'
        )

        return Response(success_response, status=status.HTTP_200_OK)


# ... rest of existing views ...