# apps/market/urls/user_urls.py
from django.urls import path
from apps.market.views.user_views import (
    MarketReportAPIView,
    MarketBookmarkAPIView,
    PublicMarketListAPIView,
    MarketCombinedSliderListAPIView,  # New view
)

app_name = 'market_user'

urlpatterns = [
    # ... existing urls ...
    path('report/', MarketReportAPIView.as_view(), name='report'),
    path('bookmark/', MarketBookmarkAPIView.as_view(), name='bookmark'),
    path('list/', PublicMarketListAPIView.as_view(), name='list'),
    
    # New combined slider endpoint
    path('<str:pk>/combined-sliders/', MarketCombinedSliderListAPIView.as_view(), name='market-combined-sliders'),
]