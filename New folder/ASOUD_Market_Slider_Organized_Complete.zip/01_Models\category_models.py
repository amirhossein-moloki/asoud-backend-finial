# apps/category/models.py
from django.db import models
from django.utils.translation import gettext_lazy as _
from apps.core.models import BaseModel


class Group(BaseModel):
    title = models.CharField(max_length=255, verbose_name=_('Title'))
    market_fee = models.DecimalField(
        max_digits=10, 
        decimal_places=2, 
        default=0.00,
        verbose_name=_('Market Fee')
    )
    market_slider_img = models.ImageField(
        upload_to='category/sliders/',
        blank=True,
        null=True,
        verbose_name=_('Market slider image'),
    )
    market_slider_url = models.CharField(
        max_length=500,  # Increased from 20
        blank=True,
        null=True,
        verbose_name=_('Market slider url'),
    )

    class Meta:
        db_table = 'group'
        verbose_name = _('Group')
        verbose_name_plural = _('Groups')

    def __str__(self):
        return self.title


class Category(BaseModel):
    group = models.ForeignKey(
        Group,
        on_delete=models.CASCADE,
        related_name='categories',
        verbose_name=_('Group')
    )
    title = models.CharField(max_length=255, verbose_name=_('Title'))
    market_fee = models.DecimalField(
        max_digits=10, 
        decimal_places=2, 
        default=0.00,
        verbose_name=_('Market Fee')
    )
    market_slider_img = models.ImageField(
        upload_to='category/sliders/',
        blank=True,
        null=True,
        verbose_name=_('Market slider image'),
    )
    market_slider_url = models.CharField(
        max_length=500,  # Increased from 20
        blank=True,
        null=True,
        verbose_name=_('Market slider url'),
    )

    class Meta:
        db_table = 'category'
        verbose_name = _('Category')
        verbose_name_plural = _('Categories')

    def __str__(self):
        return self.title


class SubCategory(BaseModel):
    category = models.ForeignKey(
        Category,
        on_delete=models.CASCADE,
        related_name='subcategories',
        verbose_name=_('Category')
    )
    title = models.CharField(max_length=255, verbose_name=_('Title'))
    market_fee = models.DecimalField(
        max_digits=10, 
        decimal_places=2, 
        default=0.00,
        verbose_name=_('Market Fee')
    )
    market_slider_img = models.ImageField(
        upload_to='category/sliders/',
        blank=True,
        null=True,
        verbose_name=_('Market slider image'),
    )
    market_slider_url = models.CharField(
        max_length=500,  # Increased from 20
        blank=True,
        null=True,
        verbose_name=_('Market slider url'),
    )

    class Meta:
        db_table = 'subcategory'
        verbose_name = _('Sub Category')
        verbose_name_plural = _('Sub Categories')

    def __str__(self):
        return self.title