# apps/market/views/user_views.py
from rest_framework import views, status, permissions
from rest_framework.response import Response
from utils.response import ApiResponse
from apps.market.models import Market, MarketSlider
from apps.market.serializers.user_serializers import MarketSliderUserSerializer
from apps.category.models import Group, Category, SubCategory


class MarketCombinedSliderListAPIView(views.APIView):
    """
    API to get combined sliders (owner sliders + admin category slider)
    """
    permission_classes = [permissions.AllowAny]

    def get(self, request, pk):
        try:
            market = Market.objects.get(pk=pk)
        except Market.DoesNotExist:
            return Response({"detail": "Market not found."}, status=status.HTTP_404_NOT_FOUND)

        # Get owner sliders
        owner_sliders = MarketSlider.objects.filter(market=market, is_active=True).order_by('order')
        owner_serializer = MarketSliderUserSerializer(owner_sliders, many=True)

        # Get admin slider for this market's category
        admin_slider_data = self.get_admin_slider_for_market(market)

        # Combine sliders
        combined_sliders = owner_serializer.data
        if admin_slider_data:
            combined_sliders.append(admin_slider_data)

        return Response(combined_sliders, status=status.HTTP_200_OK)

    def get_admin_slider_for_market(self, market):
        """
        Get admin slider based on market's sub_category, category, group priority
        """
        if market.sub_category and market.sub_category.market_slider_img:
            return {
                "id": f"admin_sub_{market.sub_category.id}",
                "image": self.request.build_absolute_uri(market.sub_category.market_slider_img.url),
                "url": market.sub_category.market_slider_url,
                "order": 9999,  # Always last
                "title": market.sub_category.title,
                "description": "Admin promotion for sub-category"
            }
        elif market.category and market.category.market_slider_img:
            return {
                "id": f"admin_cat_{market.category.id}",
                "image": self.request.build_absolute_uri(market.category.market_slider_img.url),
                "url": market.category.market_slider_url,
                "order": 9999,  # Always last
                "title": market.category.title,
                "description": "Admin promotion for category"
            }
        elif market.group and market.group.market_slider_img:
            return {
                "id": f"admin_group_{market.group.id}",
                "image": self.request.build_absolute_uri(market.group.market_slider_img.url),
                "url": market.group.market_slider_url,
                "order": 9999,  # Always last
                "title": market.group.title,
                "description": "Admin promotion for group"
            }
        return None


# ... rest of existing views ...