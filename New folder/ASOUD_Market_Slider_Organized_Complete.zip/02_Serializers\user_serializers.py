# apps/market/serializers/user_serializers.py
from rest_framework import serializers
from apps.market.models import Market, MarketSlider


class MarketSliderUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = MarketSlider
        fields = [
            'id', 'image', 'url', 'order', 'title', 'description'
        ]


class MarketListSerializer(serializers.ModelSerializer):
    # ... existing fields ...
    market_sliders = MarketSliderUserSerializer(many=True, read_only=True)
    
    class Meta:
        model = Market
        fields = [
            # ... existing fields ...
            'market_sliders',
            # ... rest of fields ...
        ]


class MarketDetailSerializer(serializers.ModelSerializer):
    # ... existing fields ...
    market_sliders = MarketSliderUserSerializer(many=True, read_only=True)
    
    class Meta:
        model = Market
        fields = [
            # ... existing fields ...
            'market_sliders',
            # ... rest of fields ...
        ]


# ... rest of existing serializers ...