# apps/market/models.py
from django.db import models
from django.utils.translation import gettext_lazy as _
from apps.core.models import BaseModel
from apps.users.models import User
from apps.category.models import Group, Category, SubCategory
from apps.location.models import Country, Province, City
from utils.upload import upload_market_logo, upload_market_background, upload_market_slider


class Market(BaseModel):
    # ... existing fields ...
    
    # Enhanced MarketSlider model
    class MarketSlider(BaseModel):
        market = models.ForeignKey(
            Market,
            on_delete=models.CASCADE,
            verbose_name=_('Market'),
            related_name='sliders'
        )
        image = models.ImageField(
            upload_to='market/sliders/',
            verbose_name=_('Slider Image')
        )
        url = models.CharField(
            max_length=500,  # Increased from 20
            blank=True,
            null=True,
            verbose_name=_('Slider URL')
        )
        order = models.PositiveIntegerField(
            default=0,
            verbose_name=_('Order'),
            help_text=_('The order in which the slider will be displayed.')
        )
        title = models.CharField(
            max_length=255,
            blank=True,
            null=True,
            verbose_name=_('Title')
        )
        description = models.TextField(
            blank=True,
            null=True,
            verbose_name=_('Description')
        )
        is_active = models.BooleanField(
            default=True,
            verbose_name=_('Is Active')
        )

        class Meta:
            db_table = 'market_slider'
            verbose_name = _('Market slider')
            verbose_name_plural = _('Market sliders')
            ordering = ['order']

        def __str__(self):
            return f"{self.market.name} - {self.title or 'Slider'}"

    # ... rest of existing Market model ...