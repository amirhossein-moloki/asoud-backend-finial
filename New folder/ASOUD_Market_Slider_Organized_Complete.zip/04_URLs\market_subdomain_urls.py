# اصلاح شده - اضافه کردن URL برای اسلایدر API
from django.urls import path
from apps.market_subdomain.views import (
    MarketDetailView,
    ProductListView,
    ProductDetailView,
    MarketSlidersAPIView
)

urlpatterns = [
    # Main market page
    path('', MarketDetailView, name='market-detail-subdomain'),
    
    # Products
    path('products/', ProductListView, name='product-list-subdomain'),
    path('products/<str:product_id>/', ProductDetailView, name='product-detail-subdomain'),
    
    # API endpoints
    path('api/sliders/', MarketSlidersAPIView, name='market-sliders-api-subdomain'),
]

