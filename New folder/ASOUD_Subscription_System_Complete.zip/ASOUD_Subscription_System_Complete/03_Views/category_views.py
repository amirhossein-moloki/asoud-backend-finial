from rest_framework import views, status, permissions
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from django.utils.translation import gettext_lazy as _

from apps.base.utils import ApiResponse
from .models import Group, Category, SubCategory
from .serializers import MarketFeeUpdateSerializer, MarketFeeListSerializer


class MarketFeeUpdateAPIView(views.APIView):
    permission_classes = [permissions.IsAuthenticated, permissions.IsAdminUser]
    
    def put(self, request, model_type, pk):
        """
        Update market fee for a specific model instance
        """
        try:
            if model_type == 'group':
                model_class = Group
            elif model_type == 'category':
                model_class = Category
            elif model_type == 'subcategory':
                model_class = SubCategory
            else:
                return Response(
                    ApiResponse(
                        success=False,
                        code=400,
                        error={'code': 'invalid_model_type', 'detail': 'Invalid model type'}
                    ),
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            instance = get_object_or_404(model_class, id=pk)
            serializer = MarketFeeUpdateSerializer(data=request.data)
            
            if serializer.is_valid(raise_exception=True):
                instance.market_fee = serializer.validated_data['market_fee']
                instance.save()
                
                success_response = ApiResponse(
                    success=True,
                    code=200,
                    data={
                        'id': instance.id,
                        'title': instance.title,
                        'market_fee': float(instance.market_fee),
                        'model_type': model_type
                    },
                    message='Market fee updated successfully.',
                )
                
                return Response(success_response, status=status.HTTP_200_OK)
                
        except Exception as e:
            return Response(
                ApiResponse(
                    success=False,
                    code=500,
                    error={'code': 'update_failed', 'detail': str(e)}
                ),
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


class MarketFeeListAPIView(views.APIView):
    permission_classes = [permissions.IsAuthenticated, permissions.IsAdminUser]
    
    def get(self, request, model_type):
        """
        List all instances with their market fees
        """
        try:
            if model_type == 'group':
                queryset = Group.objects.all()
                model_name = 'گروه'
            elif model_type == 'category':
                queryset = Category.objects.all()
                model_name = 'دسته'
            elif model_type == 'subcategory':
                queryset = SubCategory.objects.all()
                model_name = 'زیردسته'
            else:
                return Response(
                    ApiResponse(
                        success=False,
                        code=400,
                        error={'code': 'invalid_model_type', 'detail': 'Invalid model type'}
                    ),
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            data = []
            for instance in queryset:
                data.append({
                    'id': instance.id,
                    'title': instance.title,
                    'market_fee': float(instance.market_fee),
                    'fee_status': 'فعال' if instance.market_fee > 0 else 'غیرفعال'
                })
            
            success_response = ApiResponse(
                success=True,
                code=200,
                data={
                    'model_type': model_name,
                    'count': len(data),
                    'instances': data
                },
                message='Market fees retrieved successfully.',
            )
            
            return Response(success_response, status=status.HTTP_200_OK)
            
        except Exception as e:
            return Response(
                ApiResponse(
                    success=False,
                    code=500,
                    error={'code': 'retrieve_failed', 'detail': str(e)}
                ),
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
