from django.urls import path
from .views import MarketFeeUpdateAPIView, MarketFeeListAPIView

urlpatterns = [
    # اضافه شده: URLs برای مدیریت حق اشتراک
    path('market-fee/<str:model_type>/<str:pk>/', MarketFeeUpdateAPIView.as_view(), name='market-fee-update'),
    path('market-fee/<str:model_type>/', MarketFeeListAPIView.as_view(), name='market-fee-list'),
]
