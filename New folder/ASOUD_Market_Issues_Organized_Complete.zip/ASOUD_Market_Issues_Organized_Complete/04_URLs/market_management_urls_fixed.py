from django.urls import path
from apps.market.views.market_management_views_fixed import (
    MarketPreviewAPIView,
    MarketEditAPIView,
    MarketShareAPIView,
    MarketPaymentAPIView,
    MarketUnpublishAPIView,
    MarketReactivateAPIView,
    MarketListWithButtonsAPIView,
)

urlpatterns = [
    # دکمه‌های مدیریتی جدید
    path('preview/<int:pk>/', MarketPreviewAPIView.as_view(), name='market-preview'),
    path('edit/<int:pk>/', MarketEditAPIView.as_view(), name='market-edit'),
    path('share/<int:pk>/', MarketShareAPIView.as_view(), name='market-share'),
    path('payment/<int:pk>/', MarketPaymentAPIView.as_view(), name='market-payment'),
    path('unpublish/<int:pk>/', MarketUnpublishAPIView.as_view(), name='market-unpublish'),
    path('reactivate/<int:pk>/', MarketReactivateAPIView.as_view(), name='market-reactivate'),
    
    # لیست با دکمه‌های کامل
    path('list-with-buttons/', MarketListWithButtonsAPIView.as_view(), name='market-list-with-buttons'),
]
