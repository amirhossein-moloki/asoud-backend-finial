from rest_framework import serializers
from django.urls import reverse
import jdatetime
from drf_spectacular.utils import extend_schema_field
from typing import Optional

from apps.market.models import Market


class MarketListSerializerFixed(serializers.ModelSerializer):
    """
    اصلاح شده MarketListSerializer با تمام دکمه‌های مدیریتی مورد نیاز
    """
    created_at = serializers.SerializerMethodField()
    sub_category_title = serializers.SerializerMethodField()
    view_count = serializers.SerializerMethodField()
    
    # دکمه‌های مدیریتی موجود
    inactive_url = serializers.SerializerMethodField()
    queue_url = serializers.SerializerMethodField()
    
    # دکمه‌های مدیریتی گمشده که باید اضافه شوند
    preview_url = serializers.SerializerMethodField()
    edit_url = serializers.SerializerMethodField()
    share_url = serializers.SerializerMethodField()
    payment_url = serializers.SerializerMethodField()
    unpublish_url = serializers.SerializerMethodField()
    reactivate_url = serializers.SerializerMethodField()
    
    # منطق شرطی برای نمایش دکمه‌ها
    available_buttons = serializers.SerializerMethodField()

    class Meta:
        model = Market
        fields = [
            'id',
            'business_id',
            'name',
            'sub_category',
            'sub_category_title',
            'status',
            'is_paid',
            'created_at',
            'logo_img',
            'background_img',
            'view_count',
            # دکمه‌های موجود
            'inactive_url',
            'queue_url',
            # دکمه‌های جدید
            'preview_url',
            'edit_url',
            'share_url',
            'payment_url',
            'unpublish_url',
            'reactivate_url',
            # منطق دکمه‌ها
            'available_buttons',
        ]

    @extend_schema_field(serializers.CharField())
    def get_created_at(self, obj) -> str:
        created_at_date = obj.created_at.date()
        jalali_date = jdatetime.date.fromgregorian(date=created_at_date)
        return jalali_date.strftime("%Y/%m/%d")

    @extend_schema_field(serializers.CharField())
    def get_sub_category_title(self, obj) -> Optional[str]:
        return obj.sub_category.title if obj.sub_category else None

    @extend_schema_field(serializers.IntegerField())
    def get_view_count(self, obj) -> int:
        market_viewed_by = obj.viewed_by.all()
        return market_viewed_by.count()

    # دکمه‌های موجود
    def get_inactive_url(self, obj):
        request = self.context.get('request')
        return request.build_absolute_uri(
            reverse('market_owner:inactive', kwargs={'pk': obj.id})
        )

    def get_queue_url(self, obj):
        request = self.context.get('request')
        return request.build_absolute_uri(
            reverse('market_owner:queue', kwargs={'pk': obj.id})
        )

    # دکمه‌های جدید - باید view های مربوطه ایجاد شوند
    def get_preview_url(self, obj):
        request = self.context.get('request')
        return request.build_absolute_uri(
            reverse('market_owner:preview', kwargs={'pk': obj.id})
        )

    def get_edit_url(self, obj):
        request = self.context.get('request')
        return request.build_absolute_uri(
            reverse('market_owner:edit', kwargs={'pk': obj.id})
        )

    def get_share_url(self, obj):
        request = self.context.get('request')
        return request.build_absolute_uri(
            reverse('market_owner:share', kwargs={'pk': obj.id})
        )

    def get_payment_url(self, obj):
        request = self.context.get('request')
        return request.build_absolute_uri(
            reverse('market_owner:payment', kwargs={'pk': obj.id})
        )

    def get_unpublish_url(self, obj):
        request = self.context.get('request')
        return request.build_absolute_uri(
            reverse('market_owner:unpublish', kwargs={'pk': obj.id})
        )

    def get_reactivate_url(self, obj):
        request = self.context.get('request')
        return request.build_absolute_uri(
            reverse('market_owner:reactivate', kwargs={'pk': obj.id})
        )

    def get_available_buttons(self, obj):
        """
        منطق شرطی برای نمایش دکمه‌ها بر اساس وضعیت و پرداخت
        """
        buttons = {
            'edit': True,  # همیشه موجود
            'preview': True,  # همیشه موجود
            'share': False,
            'publish': False,
            'payment': False,
            'inactive': False,
            'reactivate': False,
        }
        
        # منطق شرطی بر اساس وضعیت و پرداخت
        if obj.status == Market.PUBLISHED:
            buttons['share'] = True
            buttons['inactive'] = True
        elif obj.status == Market.DRAFT and obj.is_paid:
            buttons['publish'] = True
        elif obj.status == Market.QUEUE:
            buttons['inactive'] = True
        elif obj.status == Market.NOT_PUBLISHED:
            buttons['publish'] = True
            buttons['inactive'] = True
        elif obj.status == Market.NEEDS_EDITING:
            buttons['publish'] = True
            buttons['inactive'] = True
        elif obj.status == Market.INACTIVE:
            buttons['reactivate'] = True
        
        # منطق پرداخت
        if not obj.is_paid:
            buttons['payment'] = True
        
        return buttons
