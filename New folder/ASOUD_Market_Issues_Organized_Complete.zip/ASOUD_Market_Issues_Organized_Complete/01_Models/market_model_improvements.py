from django.db import models
from django.utils.translation import gettext_lazy as _
from apps.base.models import BaseModel


class MarketModelImprovements:
    """
    بهبودهای پیشنهادی برای مدل Market
    """
    
    # فیلدهای جدید پیشنهادی
    ADDITIONAL_FIELDS = {
        'template': models.CharField(
            max_length=20,
            choices=[
                ('company', 'شرکتی'),
                ('shop', 'فروشگاهی'),
            ],
            default='shop',
            verbose_name=_('Template'),
            help_text=_('قالب فروشگاه یا شرکت')
        ),
        'working_hours': models.JSONField(
            blank=True,
            null=True,
            verbose_name=_('Working Hours'),
            help_text=_('ساعات کاری فروشگاه')
        ),
        'instagram_id': models.CharField(
            max_length=100,
            blank=True,
            null=True,
            verbose_name=_('Instagram ID'),
            help_text=_('آیدی اینستاگرام')
        ),
        'telegram_id': models.CharField(
            max_length=100,
            blank=True,
            null=True,
            verbose_name=_('Telegram ID'),
            help_text=_('آیدی تلگرام')
        ),
        'payment_gateway_type': models.CharField(
            max_length=20,
            choices=[
                ('personal', 'درگاه شخصی'),
                ('asoud', 'درگاه آسود'),
                ('later', 'بعداً'),
            ],
            blank=True,
            null=True,
            verbose_name=_('Payment Gateway Type'),
            help_text=_('نوع درگاه پرداخت')
        ),
        'payment_gateway_key': models.CharField(
            max_length=255,
            blank=True,
            null=True,
            verbose_name=_('Payment Gateway Key'),
            help_text=_('کلید درگاه پرداخت')
        ),
        'subscription_fee': models.DecimalField(
            max_digits=14,
            decimal_places=3,
            null=True,
            blank=True,
            verbose_name=_('Subscription Fee'),
            help_text=_('حق اشتراک محاسبه شده')
        ),
        'subscription_payment_status': models.CharField(
            max_length=20,
            choices=[
                ('pending', 'در انتظار پرداخت'),
                ('paid', 'پرداخت شده'),
                ('failed', 'ناموفق'),
                ('cancelled', 'لغو شده'),
            ],
            default='pending',
            verbose_name=_('Subscription Payment Status'),
            help_text=_('وضعیت پرداخت اشتراک')
        ),
        'subscription_payment_date': models.DateTimeField(
            null=True,
            blank=True,
            verbose_name=_('Subscription Payment Date'),
            help_text=_('تاریخ پرداخت اشتراک')
        ),
        'subscription_payment_reference': models.CharField(
            max_length=100,
            null=True,
            blank=True,
            verbose_name=_('Payment Reference'),
            help_text=_('مرجع پرداخت')
        ),
    }
    
    # متدهای جدید پیشنهادی
    @staticmethod
    def get_combined_status(market):
        """
        دریافت وضعیت ترکیبی بر اساس status و is_paid
        """
        status_mapping = {
            ('draft', False): 'در دست ایجاد، پرداخت نشده',
            ('draft', True): 'در دست ایجاد، پرداخت شده',
            ('queue', True): 'در صف انتشار، پرداخت شده',
            ('not_published', True): 'عدم انتشار، پرداخت شده',
            ('published', True): 'منتشر شده',
            ('needs_editing', True): 'نیاز به ویرایش، پرداخت شده',
            ('inactive', False): 'غیر فعال',
            ('inactive', True): 'غیر فعال',
        }
        
        return status_mapping.get((market.status, market.is_paid), 'نامشخص')
    
    @staticmethod
    def can_edit(market):
        """
        بررسی امکان ویرایش فروشگاه
        """
        return market.status != 'inactive'
    
    @staticmethod
    def can_share(market):
        """
        بررسی امکان اشتراک‌گذاری فروشگاه
        """
        return market.status == 'published'
    
    @staticmethod
    def can_publish(market):
        """
        بررسی امکان انتشار فروشگاه
        """
        return market.status in ['draft', 'not_published'] and market.is_paid
    
    @staticmethod
    def can_pay_subscription(market):
        """
        بررسی امکان پرداخت اشتراک
        """
        return not market.is_paid
    
    @staticmethod
    def can_unpublish(market):
        """
        بررسی امکان توقف انتشار
        """
        return market.status == 'published'
    
    @staticmethod
    def can_reactivate(market):
        """
        بررسی امکان فعال‌سازی مجدد
        """
        return market.status == 'inactive'
    
    @staticmethod
    def get_available_buttons(market):
        """
        دریافت دکمه‌های موجود بر اساس وضعیت
        """
        return {
            'edit': MarketModelImprovements.can_edit(market),
            'preview': True,  # همیشه موجود
            'share': MarketModelImprovements.can_share(market),
            'publish': MarketModelImprovements.can_publish(market),
            'payment': MarketModelImprovements.can_pay_subscription(market),
            'unpublish': MarketModelImprovements.can_unpublish(market),
            'inactive': market.status != 'inactive',
            'reactivate': MarketModelImprovements.can_reactivate(market),
        }
    
    @staticmethod
    def calculate_subscription_fee(market):
        """
        محاسبه حق اشتراک بر اساس دسته‌بندی
        """
        if market.sub_category and hasattr(market.sub_category, 'market_fee'):
            return float(market.sub_category.market_fee)
        return 0
    
    @staticmethod
    def get_status_display_fa(market):
        """
        نمایش وضعیت به فارسی
        """
        status_display = {
            'draft': 'پیش‌نویس',
            'queue': 'در صف انتشار',
            'not_published': 'عدم انتشار',
            'published': 'منتشر شده',
            'needs_editing': 'نیاز به ویرایش',
            'inactive': 'غیرفعال',
        }
        
        base_status = status_display.get(market.status, market.status)
        
        if market.is_paid:
            return f"{base_status} (پرداخت شده)"
        else:
            return f"{base_status} (پرداخت نشده)"
