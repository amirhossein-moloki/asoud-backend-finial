from rest_framework import views, status, permissions
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from django.db import transaction
from django.contrib.auth import get_user_model

from apps.market.models import Market
from apps.base.utils import ApiResponse
from apps.market.serializers.market_list_serializer_fixed import MarketListSerializerFixed

User = get_user_model()


class MarketPreviewAPIView(views.APIView):
    """
    پیش‌نمایش فروشگاه - نمایش فروشگاه به صورت مشتری
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, pk, format=None):
        market = get_object_or_404(Market, pk=pk, user=request.user)
        
        # بررسی دسترسی
        if market.user != request.user:
            return Response({
                'success': False,
                'message': 'شما دسترسی به این فروشگاه ندارید'
            }, status=status.HTTP_403_FORBIDDEN)
        
        # داده‌های پیش‌نمایش
        preview_data = {
            'market_id': market.id,
            'name': market.name,
            'business_id': market.business_id,
            'description': market.description,
            'status': market.status,
            'is_paid': market.is_paid,
            'logo_img': market.logo_img.url if market.logo_img else None,
            'background_img': market.background_img.url if market.background_img else None,
            'sub_category': market.sub_category.title if market.sub_category else None,
            'view_count': market.viewed_by.count(),
        }
        
        success_response = ApiResponse(
            success=True,
            code=200,
            data=preview_data,
            message='پیش‌نمایش فروشگاه با موفقیت دریافت شد'
        )
        
        return Response(success_response, status=status.HTTP_200_OK)


class MarketEditAPIView(views.APIView):
    """
    ویرایش فروشگاه - دسترسی به فرم ویرایش
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, pk, format=None):
        market = get_object_or_404(Market, pk=pk, user=request.user)
        
        # بررسی دسترسی
        if market.user != request.user:
            return Response({
                'success': False,
                'message': 'شما دسترسی به این فروشگاه ندارید'
            }, status=status.HTTP_403_FORBIDDEN)
        
        # بررسی وضعیت برای ویرایش
        if market.status == Market.INACTIVE:
            return Response({
                'success': False,
                'message': 'فروشگاه غیرفعال است و قابل ویرایش نیست'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # داده‌های ویرایش
        edit_data = {
            'market_id': market.id,
            'edit_url': f'/market/edit/{market.id}/',
            'current_data': {
                'name': market.name,
                'business_id': market.business_id,
                'description': market.description,
                'status': market.status,
                'is_paid': market.is_paid,
            }
        }
        
        success_response = ApiResponse(
            success=True,
            code=200,
            data=edit_data,
            message='دسترسی به ویرایش فروشگاه فراهم شد'
        )
        
        return Response(success_response, status=status.HTTP_200_OK)


class MarketShareAPIView(views.APIView):
    """
    اشتراک‌گذاری فروشگاه - فقط برای فروشگاه‌های منتشر شده
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, pk, format=None):
        market = get_object_or_404(Market, pk=pk, user=request.user)
        
        # بررسی دسترسی
        if market.user != request.user:
            return Response({
                'success': False,
                'message': 'شما دسترسی به این فروشگاه ندارید'
            }, status=status.HTTP_403_FORBIDDEN)
        
        # بررسی وضعیت برای اشتراک‌گذاری
        if market.status != Market.PUBLISHED:
            return Response({
                'success': False,
                'message': 'فقط فروشگاه‌های منتشر شده قابل اشتراک‌گذاری هستند'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # داده‌های اشتراک‌گذاری
        share_data = {
            'market_id': market.id,
            'share_url': f'/market/share/{market.id}/',
            'market_name': market.name,
            'business_id': market.business_id,
            'share_text': f'فروشگاه {market.name} را در آسود مشاهده کنید',
        }
        
        success_response = ApiResponse(
            success=True,
            code=200,
            data=share_data,
            message='لینک اشتراک‌گذاری فروشگاه ایجاد شد'
        )
        
        return Response(success_response, status=status.HTTP_200_OK)


class MarketPaymentAPIView(views.APIView):
    """
    پرداخت اشتراک فروشگاه
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, pk, format=None):
        market = get_object_or_404(Market, pk=pk, user=request.user)
        
        # بررسی دسترسی
        if market.user != request.user:
            return Response({
                'success': False,
                'message': 'شما دسترسی به این فروشگاه ندارید'
            }, status=status.HTTP_403_FORBIDDEN)
        
        # بررسی وضعیت پرداخت
        if market.is_paid:
            return Response({
                'success': False,
                'message': 'اشتراک این فروشگاه قبلاً پرداخت شده است'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # محاسبه حق اشتراک
        subscription_fee = 0
        if market.sub_category and hasattr(market.sub_category, 'market_fee'):
            subscription_fee = float(market.sub_category.market_fee)
        
        # داده‌های پرداخت
        payment_data = {
            'market_id': market.id,
            'subscription_fee': subscription_fee,
            'currency': 'تومان',
            'payment_url': f'/payment/subscription/{market.id}/',
            'discount_available': True,
        }
        
        success_response = ApiResponse(
            success=True,
            code=200,
            data=payment_data,
            message='اطلاعات پرداخت اشتراک دریافت شد'
        )
        
        return Response(success_response, status=status.HTTP_200_OK)


class MarketUnpublishAPIView(views.APIView):
    """
    عدم انتشار فروشگاه - توقف انتشار
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, pk, format=None):
        market = get_object_or_404(Market, pk=pk, user=request.user)
        
        # بررسی دسترسی
        if market.user != request.user:
            return Response({
                'success': False,
                'message': 'شما دسترسی به این فروشگاه ندارید'
            }, status=status.HTTP_403_FORBIDDEN)
        
        # بررسی وضعیت برای عدم انتشار
        if market.status != Market.PUBLISHED:
            return Response({
                'success': False,
                'message': 'فقط فروشگاه‌های منتشر شده قابل توقف انتشار هستند'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        with transaction.atomic():
            # تغییر وضعیت به عدم انتشار
            market.status = Market.NOT_PUBLISHED
            market.save()
        
        success_response = ApiResponse(
            success=True,
            code=200,
            data={'market_id': market.id, 'new_status': market.status},
            message='انتشار فروشگاه متوقف شد'
        )
        
        return Response(success_response, status=status.HTTP_200_OK)


class MarketReactivateAPIView(views.APIView):
    """
    فعال‌سازی مجدد فروشگاه - فقط برای فروشگاه‌های غیرفعال
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, pk, format=None):
        market = get_object_or_404(Market, pk=pk, user=request.user)
        
        # بررسی دسترسی
        if market.user != request.user:
            return Response({
                'success': False,
                'message': 'شما دسترسی به این فروشگاه ندارید'
            }, status=status.HTTP_403_FORBIDDEN)
        
        # بررسی وضعیت برای فعال‌سازی مجدد
        if market.status != Market.INACTIVE:
            return Response({
                'success': False,
                'message': 'فقط فروشگاه‌های غیرفعال قابل فعال‌سازی مجدد هستند'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        with transaction.atomic():
            # تغییر وضعیت به پیش‌نویس
            market.status = Market.DRAFT
            market.save()
        
        success_response = ApiResponse(
            success=True,
            code=200,
            data={'market_id': market.id, 'new_status': market.status},
            message='فروشگاه با موفقیت فعال‌سازی شد'
        )
        
        return Response(success_response, status=status.HTTP_200_OK)


class MarketListWithButtonsAPIView(views.APIView):
    """
    لیست فروشگاه‌ها با دکمه‌های مدیریتی کامل
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, format=None):
        user_obj = request.user
        
        # دریافت لیست فروشگاه‌های کاربر
        market_list = Market.objects.filter(user=user_obj).order_by('-created_at')
        
        # استفاده از serializer اصلاح شده
        serializer = MarketListSerializerFixed(
            market_list,
            many=True,
            context={"request": request},
        )
        
        success_response = ApiResponse(
            success=True,
            code=200,
            data=serializer.data,
            message='لیست فروشگاه‌ها با دکمه‌های مدیریتی دریافت شد'
        )
        
        return Response(success_response, status=status.HTTP_200_OK)
