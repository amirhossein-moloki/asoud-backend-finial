# راهنمای API برای فرانت‌اند - Asoud Platform

## 📋 اطلاعات کلی

- **نام پروژه:** Asoud API
- **نسخه:** 1.0.0
- **نوع دیتابیس:** SQLite (Development) / PostgreSQL (Production)
- **Encoding:** UTF-8 (فارسی)

## 🔗 API Endpoints

### Base URL
```
http://localhost:8000/api/v1
```

### Endpoints اصلی
- **شهرها:** `GET /region/city/list/`
- **استان‌ها:** `GET /region/province/list/`
- **کشورها:** `GET /region/country/list/`
- **بازارها:** `GET /user/market/`
- **محصولات:** `GET /user/product/`
- **دسته‌بندی‌ها:** `GET /category/list/`

## 🔐 احراز هویت

### نوع احراز هویت
Token Authentication

### Header مورد نیاز
```
Authorization: Bearer YOUR_TOKEN
Content-Type: application/json
```

### Endpoints احراز هویت
- **ورود:** `POST /auth/login/`
- **ثبت‌نام:** `POST /auth/register/`

## 📊 داده‌های نمونه

### شهرها (Cities)
```json
[
  {
    "id": "70fa70b7-2347-4d10-a187-ca6925b66d06",
    "name": "تهران"
  },
  {
    "id": "a50a3018-7840-418e-96de-008588219ad3",
    "name": "کرج"
  },
  {
    "id": "1f7d5847-6cd3-455c-af44-25a142585c62",
    "name": "ورامین"
  }
]
```

### بازارها (Markets)
```json
[
  {
    "id": "5b293630-8df4-4c01-9f8b-e7ea3a3aea49",
    "name": "بازار نمونه 1",
    "business_id": "market_001"
  },
  {
    "id": "d502d25b-1f4e-4948-9818-a36db481d285",
    "name": "بازار نمونه 2",
    "business_id": "market_002"
  }
]
```

## 📝 فرمت Response

### لیست شهرها
```json
{
  "success": true,
  "code": 200,
  "data": [
    {
      "id": "70fa70b7-2347-4d10-a187-ca6925b66d06",
      "name": "تهران"
    }
  ],
  "message": "Data retrieved successfully"
}
```

### جزئیات بازار
```json
{
  "success": true,
  "code": 200,
  "data": {
    "id": "5b293630-8df4-4c01-9f8b-e7ea3a3aea49",
    "name": "بازار نمونه",
    "business_id": "market_001",
    "description": "توضیحات بازار نمونه",
    "type": "shop",
    "status": "published",
    "is_paid": true
  },
  "message": "Market retrieved successfully"
}
```

## 🆔 UUID Information

### فرمت UUID
- **نوع:** UUID4 (36 کاراکتر)
- **مثال شهر:** `70fa70b7-2347-4d10-a187-ca6925b66d06`
- **مثال بازار:** `5b293630-8df4-4c01-9f8b-e7ea3a3aea49`

### آمار داده‌ها
- **تعداد شهرها:** 157
- **تعداد استان‌ها:** 16
- **تعداد کشورها:** 1 (ایران)
- **تعداد دسته‌بندی‌ها:** 30
- **تعداد زیردسته‌ها:** 140

## 🎯 راهنمای استفاده

### 1. دریافت لیست شهرها
```javascript
const response = await fetch('/api/v1/region/city/list/', {
  headers: {
    'Authorization': 'Bearer YOUR_TOKEN',
    'Content-Type': 'application/json'
  }
});

const data = await response.json();
if (data.success) {
  const cities = data.data;
  // استفاده از cities
}
```

### 2. دریافت جزئیات بازار
```javascript
const marketId = '5b293630-8df4-4c01-9f8b-e7ea3a3aea49';
const response = await fetch(`/api/v1/user/market/${marketId}/`, {
  headers: {
    'Authorization': 'Bearer YOUR_TOKEN',
    'Content-Type': 'application/json'
  }
});

const data = await response.json();
if (data.success) {
  const market = data.data;
  // استفاده از market
}
```

## ⚠️ نکات مهم

1. **احراز هویت:** تمام endpointها نیاز به token دارند
2. **Encoding:** از UTF-8 استفاده کنید
3. **Error Handling:** همیشه فیلد `success` را بررسی کنید
4. **Headers:** حتماً `Authorization` و `Content-Type` را ارسال کنید
5. **Pagination:** هنوز پیاده‌سازی نشده است

## 📁 فایل‌های مرتبط

- `asoud_api_data.json` - داده‌های کامل API
- `complete_database_seeder.py` - اسکریپت پر کردن دیتابیس
- `postgresql_seeder.py` - اسکریپت PostgreSQL

## 🚀 شروع سریع

1. سرور را اجرا کنید:
```bash
export USE_SQLITE=true
python3 manage.py runserver 0.0.0.0:8000
```

2. Token دریافت کنید:
```bash
curl -X POST http://localhost:8000/api/v1/auth/login/ \
  -H "Content-Type: application/json" \
  -d '{"mobile_number": "09123456789", "password": "your_password"}'
```

3. از API استفاده کنید:
```bash
curl -H "Authorization: Bearer YOUR_TOKEN" \
  http://localhost:8000/api/v1/region/city/list/
```

---
**تاریخ ایجاد:** 2025-10-13  
**نسخه:** 1.0.0  
**وضعیت:** Development
