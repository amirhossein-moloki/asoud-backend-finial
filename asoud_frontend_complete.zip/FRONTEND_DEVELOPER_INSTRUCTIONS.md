# دستورالعمل کامل برای فرانت‌اند کار - پروژه Asoud

## 🎯 **خلاصه پروژه**
پروژه Asoud یک پلتفرم تجارت الکترونیک است که شامل:
- **Backend:** Django REST Framework
- **Database:** SQLite (Development) / PostgreSQL (Production)
- **Authentication:** Token-based
- **API:** RESTful API با فرمت JSON

---

## 📋 **فایل‌های مهم برای فرانت‌اند**

### 1. **فایل ZIP اصلی**
```
asoud_frontend_data.zip
```
شامل تمام فایل‌های مورد نیاز

### 2. **فایل‌های کلیدی**
- `asoud_api_data.json` - داده‌های نمونه و UUIDها
- `FRONTEND_API_GUIDE.md` - راهنمای کامل API
- `complete_database_seeder.py` - اسکریپت پر کردن دیتابیس

---

## 🔗 **API Endpoints اصلی**

### Base URL
```
http://localhost:8000/api/v1
```

### Endpoints مهم
| Endpoint | Method | توضیحات |
|----------|--------|---------|
| `/region/city/list/` | GET | لیست شهرها |
| `/region/province/list/` | GET | لیست استان‌ها |
| `/region/country/list/` | GET | لیست کشورها |
| `/user/market/` | GET | لیست بازارها |
| `/user/market/{id}/` | GET | جزئیات بازار |
| `/auth/login/` | POST | ورود کاربر |
| `/auth/register/` | POST | ثبت‌نام کاربر |

---

## 🔐 **احراز هویت**

### نوع احراز هویت
**Token Authentication**

### Header مورد نیاز
```javascript
{
  'Authorization': 'Bearer YOUR_TOKEN',
  'Content-Type': 'application/json'
}
```

### نحوه دریافت Token
```javascript
// 1. ورود کاربر
const loginResponse = await fetch('/api/v1/auth/login/', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    mobile_number: '09123456789',
    password: 'your_password'
  })
});

const loginData = await loginResponse.json();
const token = loginData.data.token;

// 2. استفاده از Token در درخواست‌های بعدی
const response = await fetch('/api/v1/region/city/list/', {
  headers: {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  }
});
```

---

## 🆔 **UUIDهای پیش‌فرض**

### شهرهای مهم
```json
{
  "تهران": "70fa70b7-2347-4d10-a187-ca6925b66d06",
  "کرج": "a50a3018-7840-418e-96de-008588219ad3",
  "ورامین": "1f7d5847-6cd3-455c-af44-25a142585c62",
  "دماوند": "97cc3d9f-1692-4b1a-b218-ba85f8eb52f2",
  "اصفهان": "3b40e9ff-1c19-416f-a853-477697f27790",
  "شیراز": "9b3cde02-f9b8-44fd-85ae-a3cfddf5d5fd"
}
```

### بازارهای نمونه
```json
{
  "بازار نمونه 1": "5b293630-8df4-4c01-9f8b-e7ea3a3aea49",
  "بازار نمونه 2": "d502d25b-1f4e-4948-9818-a36db481d285",
  "بازار نمونه 3": "5479360c-3a73-4ddf-b4a2-411c819cdb3b"
}
```

---

## 📊 **فرمت Response**

### لیست شهرها
```json
{
  "success": true,
  "code": 200,
  "data": [
    {
      "id": "70fa70b7-2347-4d10-a187-ca6925b66d06",
      "name": "تهران"
    },
    {
      "id": "a50a3018-7840-418e-96de-008588219ad3",
      "name": "کرج"
    }
  ],
  "message": "Data retrieved successfully"
}
```

### جزئیات بازار
```json
{
  "success": true,
  "code": 200,
  "data": {
    "id": "5b293630-8df4-4c01-9f8b-e7ea3a3aea49",
    "name": "بازار نمونه",
    "business_id": "market_001",
    "description": "توضیحات بازار نمونه",
    "type": "shop",
    "status": "published",
    "is_paid": true,
    "location": {
      "city": "تهران",
      "address": "آدرس نمونه"
    }
  },
  "message": "Market retrieved successfully"
}
```

### Response خطا
```json
{
  "success": false,
  "code": 401,
  "error": "Authentication failed",
  "message": "Invalid or missing authentication credentials"
}
```

---

## 💻 **مثال‌های کد JavaScript**

### 1. دریافت لیست شهرها
```javascript
async function getCities() {
  try {
    const response = await fetch('/api/v1/region/city/list/', {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    const data = await response.json();
    
    if (data.success) {
      const cities = data.data;
      console.log('شهرها:', cities);
      return cities;
    } else {
      console.error('خطا:', data.message);
      return [];
    }
  } catch (error) {
    console.error('خطای شبکه:', error);
    return [];
  }
}
```

### 2. دریافت جزئیات بازار
```javascript
async function getMarketDetails(marketId) {
  try {
    const response = await fetch(`/api/v1/user/market/${marketId}/`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    const data = await response.json();
    
    if (data.success) {
      const market = data.data;
      console.log('جزئیات بازار:', market);
      return market;
    } else {
      console.error('خطا:', data.message);
      return null;
    }
  } catch (error) {
    console.error('خطای شبکه:', error);
    return null;
  }
}
```

### 3. مدیریت خطا
```javascript
function handleApiError(response) {
  if (!response.success) {
    switch (response.code) {
      case 401:
        // احراز هویت ناموفق - به صفحه ورود هدایت کن
        window.location.href = '/login';
        break;
      case 403:
        // دسترسی غیرمجاز
        alert('شما دسترسی لازم را ندارید');
        break;
      case 404:
        // داده یافت نشد
        alert('داده مورد نظر یافت نشد');
        break;
      case 500:
        // خطای سرور
        alert('خطای سرور. لطفاً دوباره تلاش کنید');
        break;
      default:
        alert('خطای غیرمنتظره: ' + response.message);
    }
  }
}
```

---

## 🚀 **راه‌اندازی پروژه**

### 1. نصب وابستگی‌ها
```bash
# نصب Python packages
pip install -r requirements.txt

# یا برای development
pip install -r requirements-dev.txt
```

### 2. راه‌اندازی دیتابیس
```bash
# برای SQLite (Development)
export USE_SQLITE=true
python3 manage.py migrate
python3 complete_database_seeder.py

# برای PostgreSQL (Production)
export DJANGO_SETTINGS_MODULE=config.settings.production
python3 manage.py migrate
python3 postgresql_seeder.py
```

### 3. اجرای سرور
```bash
# Development
export USE_SQLITE=true
python3 manage.py runserver 0.0.0.0:8000

# Production
export DJANGO_SETTINGS_MODULE=config.settings.production
python3 manage.py runserver 0.0.0.0:8000
```

---

## ⚠️ **نکات مهم**

### 1. **احراز هویت**
- تمام endpointها نیاز به token دارند
- Token را در localStorage ذخیره کنید
- Token منقضی می‌شود - مدیریت کنید

### 2. **Encoding**
- از UTF-8 استفاده کنید
- متن‌های فارسی را درست نمایش دهید

### 3. **Error Handling**
- همیشه فیلد `success` را بررسی کنید
- کدهای خطا را مدیریت کنید

### 4. **Headers**
- حتماً `Authorization` و `Content-Type` را ارسال کنید

### 5. **CORS**
- اگر از دامنه دیگری درخواست می‌زنید، CORS را بررسی کنید

---

## 📱 **مثال کامل React Component**

```jsx
import React, { useState, useEffect } from 'react';

const CitySelector = () => {
  const [cities, setCities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchCities();
  }, []);

  const fetchCities = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/v1/region/city/list/', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      const data = await response.json();

      if (data.success) {
        setCities(data.data);
      } else {
        setError(data.message);
      }
    } catch (err) {
      setError('خطای شبکه');
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div>در حال بارگذاری...</div>;
  if (error) return <div>خطا: {error}</div>;

  return (
    <select>
      <option value="">شهر را انتخاب کنید</option>
      {cities.map(city => (
        <option key={city.id} value={city.id}>
          {city.name}
        </option>
      ))}
    </select>
  );
};

export default CitySelector;
```

---

## 📞 **پشتیبانی**

اگر سوالی دارید:
1. ابتدا `FRONTEND_API_GUIDE.md` را مطالعه کنید
2. از `asoud_api_data.json` برای داده‌های نمونه استفاده کنید
3. مثال‌های کد را بررسی کنید

---

**تاریخ ایجاد:** 2025-10-13  
**نسخه:** 1.0.0  
**وضعیت:** Ready for Frontend Development
