#!/usr/bin/env python3
"""
اسکریپت پر کردن دیتابیس PostgreSQL برای production
PostgreSQL Database Seeder for Production
"""
import os
import sys
import django
import uuid
import random
from datetime import datetime, timedelta
from decimal import Decimal

# Setup Django for production
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings.production')
django.setup()

from django.db import transaction
from apps.region.models import Country, Province, City
from apps.category.models import Group, Category, SubCategory

print("="*80)
print("🚀 اسکریپت پر کردن دیتابیس PostgreSQL - Asoud Production")
print("="*80)
print()

def create_regions():
    """ایجاد داده‌های منطقه‌ای کامل"""
    print("1️⃣  ایجاد داده‌های منطقه‌ای...")
    print("-" * 50)
    
    # ایجاد ایران
    country, created = Country.objects.get_or_create(name='ایران')
    print(f"✓ کشور: {country.name} (ID: {country.id})")
    
    # استان‌ها و شهرهای ایران
    iran_data = {
        'تهران': [
            'تهران', 'کرج', 'ورامین', 'دماوند', 'رودهن', 'شهریار', 'اسلامشهر', 
            'پاکدشت', 'فیروزکوه', 'ری', 'ملارد', 'قدس', 'بهارستان'
        ],
        'اصفهان': [
            'اصفهان', 'کاشان', 'نجف‌آباد', 'خمینی‌شهر', 'شاهین‌شهر', 'فلاورجان',
            'لنجان', 'مبارکه', 'نطنز', 'اردستان', 'نایین', 'تیران و کرون'
        ],
        'فارس': [
            'شیراز', 'مرودشت', 'جهرم', 'کازرون', 'لار', 'آباده', 'فسا', 'داراب',
            'لارستان', 'استهبان', 'نی‌ریز', 'فراشبند'
        ],
        'خراسان رضوی': [
            'مشهد', 'نیشابور', 'سبزوار', 'قوچان', 'کاشمر', 'تربت حیدریه',
            'تربت جام', 'چناران', 'کلات', 'درگز', 'فریمان', 'خواف'
        ],
        'آذربایجان شرقی': [
            'تبریز', 'مراغه', 'مرند', 'میانه', 'سراب', 'بناب', 'اهر', 'هشترود',
            'شبستر', 'کلیبر', 'ورزقان', 'هریس'
        ],
        'خوزستان': [
            'اهواز', 'دزفول', 'آبادان', 'خرمشهر', 'اندیمشک', 'شوشتر', 'مسجدسلیمان',
            'ایذه', 'بندر ماهشهر', 'رامهرمز', 'لالی', 'هویزه'
        ],
        'مازندران': [
            'ساری', 'بابل', 'آمل', 'قائم‌شهر', 'بابلسر', 'نوشهر', 'چالوس',
            'تنکابن', 'رامسر', 'نکا', 'فریدونکنار', 'کلاردشت'
        ],
        'گیلان': [
            'رشت', 'انزلی', 'لاهیجان', 'لنگرود', 'رودسر', 'آستارا', 'فومن',
            'صومعه‌سرا', 'رودبار', 'تالش', 'ماسال', 'شفت'
        ],
        'کرمان': [
            'کرمان', 'رفسنجان', 'سیرجان', 'زرند', 'بم', 'جیرفت', 'شهربابک',
            'کهنوج', 'بردسیر', 'قلعه گنج', 'عنبرآباد', 'رابر'
        ],
        'یزد': [
            'یزد', 'میبد', 'اردکان', 'بافق', 'مهریز', 'ابرکوه', 'تفت',
            'هرات', 'بهاباد', 'اشکذر', 'خاتم', 'بندرعباس'
        ],
        'کرمانشاه': [
            'کرمانشاه', 'اسلام‌آباد غرب', 'کنگاور', 'هرسین', 'صحنه', 'قصرشیرین',
            'سرپل ذهاب', 'گیلان غرب', 'دالاهو', 'ثلاث باباجانی', 'جوانرود'
        ],
        'لرستان': [
            'خرم‌آباد', 'بروجرد', 'دورود', 'کوهدشت', 'الیگودرز', 'نورآباد',
            'ازنا', 'سلسله', 'دلفان', 'رومشکان', 'پل‌دختر'
        ],
        'همدان': [
            'همدان', 'ملایر', 'نهاوند', 'تویسرکان', 'کبودراهنگ', 'بهار',
            'رزن', 'فامنین', 'اسدآباد', 'قروه', 'سراب'
        ],
        'آذربایجان غربی': [
            'ارومیه', 'خوی', 'مهاباد', 'بوکان', 'سلماس', 'میاندوآب',
            'سقز', 'بانه', 'مریوان', 'نقده', 'تکاب'
        ],
        'کردستان': [
            'سنندج', 'مریوان', 'سقز', 'بانه', 'قروه', 'کامیاران',
            'بیجار', 'دیواندره', 'سروآباد', 'کامیاران'
        ],
        'سیستان و بلوچستان': [
            'زاهدان', 'زابل', 'چابهار', 'ایرانشهر', 'خاش', 'سراوان',
            'کنارک', 'نیک‌شهر', 'راسک', 'دلگان'
        ]
    }
    
    total_cities = 0
    for province_name, cities in iran_data.items():
        province, created = Province.objects.get_or_create(
            name=province_name,
            country=country
        )
        print(f"  {'✅' if created else '✓'} استان: {province_name}")
        
        for city_name in cities:
            city, created = City.objects.get_or_create(
                name=city_name,
                province=province
            )
            total_cities += 1
    
    print(f"✅ مجموع: {Province.objects.count()} استان، {total_cities} شهر")
    print()

def create_categories():
    """ایجاد دسته‌بندی‌های کامل"""
    print("2️⃣  ایجاد دسته‌بندی‌ها...")
    print("-" * 50)
    
    categories_data = {
        'غذا و نوشیدنی': {
            'market_fee': 50000,
            'categories': {
                'رستوران': {
                    'market_fee': 55000,
                    'subcategories': [
                        'رستوران ایرانی', 'رستوران فرنگی', 'رستوران چینی',
                        'رستوران ایتالیایی', 'رستوران مکزیکی', 'رستوران ژاپنی',
                        'رستوران ترکی', 'رستوران عربی', 'رستوران هندی'
                    ]
                },
                'فست فود': {
                    'market_fee': 45000,
                    'subcategories': [
                        'برگر', 'پیتزا', 'ساندویچ', 'سوخاری', 'هات داگ',
                        'کباب ترکی', 'شاورما', 'فالافل', 'سوشی'
                    ]
                },
                'کافه': {
                    'market_fee': 35000,
                    'subcategories': [
                        'کافه مدرن', 'کافه سنتی', 'کافه کتاب', 'قهوه‌خانه',
                        'کافه اینترنت', 'کافه بازی'
                    ]
                },
                'شیرینی و قنادی': {
                    'market_fee': 40000,
                    'subcategories': [
                        'شیرینی خشک', 'شیرینی تر', 'کیک و کلوچه', 'بستنی',
                        'دسر', 'شکلات', 'آبنبات'
                    ]
                },
                'سوپرمارکت': {
                    'market_fee': 30000,
                    'subcategories': [
                        'مواد غذایی', 'نوشیدنی', 'میوه و سبزی', 'لبنیات',
                        'گوشت و مرغ', 'نان و شیرینی'
                    ]
                }
            }
        },
        'پوشاک و مد': {
            'market_fee': 40000,
            'categories': {
                'لباس مردانه': {
                    'market_fee': 35000,
                    'subcategories': [
                        'تی‌شرت', 'پیراهن', 'شلوار', 'کت و شلوار',
                        'لباس ورزشی', 'لباس زیر', 'لباس مجلسی'
                    ]
                },
                'لباس زنانه': {
                    'market_fee': 45000,
                    'subcategories': [
                        'مانتو', 'شلوار', 'تونیک', 'پالتو', 'لباس مجلسی',
                        'لباس ورزشی', 'لباس زیر', 'لباس بارداری'
                    ]
                },
                'کفش': {
                    'market_fee': 50000,
                    'subcategories': [
                        'کفش مردانه', 'کفش زنانه', 'کفش بچگانه', 'کفش ورزشی',
                        'کفش رسمی', 'کفش کتانی', 'صندل'
                    ]
                },
                'کیف و کوله': {
                    'market_fee': 30000,
                    'subcategories': [
                        'کیف دستی', 'کوله پشتی', 'کیف لپ‌تاپ', 'کیف مدرسه',
                        'کیف مسافرتی', 'کیف ورزشی'
                    ]
                }
            }
        },
        'دیجیتال و الکترونیک': {
            'market_fee': 60000,
            'categories': {
                'موبایل و تبلت': {
                    'market_fee': 70000,
                    'subcategories': [
                        'گوشی هوشمند', 'تبلت', 'لوازم جانبی موبایل',
                        'قاب و محافظ', 'شارژر', 'هدست'
                    ]
                },
                'کامپیوتر': {
                    'market_fee': 80000,
                    'subcategories': [
                        'لپ‌تاپ', 'کامپیوتر رومیزی', 'مانیتور', 'کیبورد و ماوس',
                        'اسپیکر', 'وب‌کم', 'پرینتر'
                    ]
                },
                'لوازم خانگی': {
                    'market_fee': 100000,
                    'subcategories': [
                        'یخچال و فریزر', 'ماشین لباسشویی', 'جاروبرقی',
                        'اجاق گاز', 'مایکروویو', 'کولر'
                    ]
                }
            }
        },
        'خانه و آشپزخانه': {
            'market_fee': 45000,
            'categories': {
                'مبلمان': {
                    'market_fee': 60000,
                    'subcategories': [
                        'مبل راحتی', 'میز و صندلی', 'کمد', 'تخت خواب',
                        'میز نهارخوری', 'میز کار', 'قفسه کتاب'
                    ]
                },
                'لوازم آشپزخانه': {
                    'market_fee': 35000,
                    'subcategories': [
                        'ظروف', 'لوازم پخت و پز', 'چاقو و قاشق',
                        'ابزار آشپزی', 'مخلوط‌کن', 'آبمیوه‌گیری'
                    ]
                },
                'دکوراسیون': {
                    'market_fee': 40000,
                    'subcategories': [
                        'تابلو', 'فرش', 'پرده', 'گلدان', 'آینه',
                        'ساعت دیواری', 'شمع', 'عکس'
                    ]
                }
            }
        },
        'ورزش و تفریح': {
            'market_fee': 50000,
            'categories': {
                'ورزشی': {
                    'market_fee': 60000,
                    'subcategories': [
                        'لباس ورزشی', 'کفش ورزشی', 'تجهیزات ورزشی',
                        'وزنه', 'طناب', 'توپ'
                    ]
                },
                'تفریحی': {
                    'market_fee': 40000,
                    'subcategories': [
                        'بازی‌های فکری', 'پازل', 'عروسک', 'اسباب‌بازی',
                        'کتاب', 'مجله', 'سی‌دی و دی‌وی‌دی'
                    ]
                }
            }
        }
    }
    
    for group_name, group_data in categories_data.items():
        group, created = Group.objects.get_or_create(
            title=group_name,
            defaults={'market_fee': group_data['market_fee']}
        )
        print(f"  {'✅' if created else '✓'} گروه: {group_name}")
        
        for category_name, category_data in group_data['categories'].items():
            category, created = Category.objects.get_or_create(
                title=category_name,
                group=group,
                defaults={'market_fee': category_data['market_fee']}
            )
            print(f"    {'✅' if created else '✓'} دسته: {category_name}")
            
            for subcategory_name in category_data['subcategories']:
                subcategory, created = SubCategory.objects.get_or_create(
                    title=subcategory_name,
                    category=category,
                    defaults={'market_fee': category_data['market_fee'] * 0.8}
                )
    
    print(f"✅ مجموع: {Group.objects.count()} گروه، {Category.objects.count()} دسته، {SubCategory.objects.count()} زیردسته")
    print()

def main():
    """اجرای اصلی اسکریپت"""
    try:
        with transaction.atomic():
            create_regions()
            create_categories()
        
        print("="*80)
        print("🎉 اسکریپت PostgreSQL با موفقیت تکمیل شد!")
        print("="*80)
        
        # نمایش آمار نهایی
        print("\n📊 آمار نهایی:")
        print(f"  کشورها: {Country.objects.count()}")
        print(f"  استان‌ها: {Province.objects.count()}")
        print(f"  شهرها: {City.objects.count()}")
        print(f"  گروه‌ها: {Group.objects.count()}")
        print(f"  دسته‌ها: {Category.objects.count()}")
        print(f"  زیردسته‌ها: {SubCategory.objects.count()}")
        
        print("\n🔗 برای استفاده در production:")
        print("   export DJANGO_SETTINGS_MODULE=config.settings.production")
        print("   python3 postgresql_seeder.py")
        
    except Exception as e:
        print(f"❌ خطا در اجرای اسکریپت: {e}")
        raise

if __name__ == "__main__":
    main()
